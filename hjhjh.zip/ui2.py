import json
import pickle
import sys

from PyQt5.QtWidgets import QApplication, QMessageBox, QFileDialog, QMainWindow, QAction, QTabWidget, QTableWidgetItem

import logging

# Set the logging level for pyqode to CRITICAL to suppress less severe messages
from tabs.clustering import ClusteringTab
from tabs.exclusions import ReductionTab
from tabs.parsing import ParsingTab
from tabs.preprocessing import PreprocessingTab
from tabs.testing import TestingTab
from tabs.translation import TranslationBundleTab

logging.getLogger('pyqode').setLevel(logging.CRITICAL)

# If necessary, apply this to other relevant loggers as well
logging.getLogger('pyqode.core.backend.server').setLevel(logging.CRITICAL)
logging.getLogger('pyqode.python.backend').setLevel(logging.CRITICAL)

from tabs.file_import import TextFileTab
from tabs.transformation import TransformationTab


class ParserModel:
    def __init__(self):
        self.loaded_filename = None
        self.text_content = ""
        self.transformations = []
        self.translations = []
        self.reductions = []
        self.preprocessing_order = []
        self.feature_extractors = []
        self.clustering_model = None
        self.cluster_parsers = {}
        self.clustering_model = None
        self.cluster_parsers = {}
        self.baseline = ""


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.current_project = ParserModel()
        self.is_project_modified = False
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Parser Project Manager')

        # Menu bar
        menubar = self.menuBar()
        file_menu = menubar.addMenu('File')

        # New Project action
        new_project_action = QAction('New Project', self)
        new_project_action.triggered.connect(self.new_project)
        file_menu.addAction(new_project_action)

        # Save Project action
        save_project_action = QAction('Save Project', self)
        save_project_action.triggered.connect(self.save_project)
        file_menu.addAction(save_project_action)

        # Load Project action
        load_project_action = QAction('Load Project', self)
        load_project_action.triggered.connect(self.load_project)
        file_menu.addAction(load_project_action)

        # Exit action
        exit_action = QAction('Exit', self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        # Tabs
        self.tab_widget = QTabWidget()
        self.setCentralWidget(self.tab_widget)

        self.tab_widget.currentChanged.connect(self.on_tab_changed)
        # Add the tabs
        self.add_tabs()

        self.setGeometry(100, 100, 1500, 800)

    def on_tab_changed(self, index):
        if index == 1:
            self.transformation_tab.show_baseline()
        if index == 2:
            self.translation_bundle_tab.show_baseline()
        if index == 3:
            self.reduction_tab.show_baseline()
        if index == 4:
            self.preprocessing_tab.show_baseline()

        if index == 5:
            self.clustering_tab.show_baseline()

    def add_tabs(self):
        self.text_file_tab = TextFileTab(self)
        self.tab_widget.addTab(self.text_file_tab, "Text File")

        self.transformation_tab = TransformationTab(self)
        self.tab_widget.addTab(self.transformation_tab, "Transformation")

        self.translation_bundle_tab = TranslationBundleTab(self)
        self.tab_widget.addTab(self.translation_bundle_tab, "Translation Bundle")

        self.reduction_tab = ReductionTab(self)
        self.tab_widget.addTab(self.reduction_tab, "Exclusion")

        self.preprocessing_tab = PreprocessingTab(self)
        self.tab_widget.addTab(self.preprocessing_tab, "Preprocessing")

        self.clustering_tab = ClusteringTab(self)
        self.tab_widget.addTab(self.clustering_tab, "Clustering")

        self.parsing_tab = ParsingTab(self)
        self.tab_widget.addTab(self.parsing_tab, "Parsing")

        self.testing_tab = TestingTab(self)
        self.tab_widget.addTab(self.testing_tab, "Testing & Export")


    def new_project(self):
        if self.is_project_modified:
            reply = QMessageBox.question(
                self, 'Save Project',
                "Do you want to save the current project before creating a new one?",
                QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel, QMessageBox.Cancel
            )
            if reply == QMessageBox.Yes:
                if not self.save_project():
                    return
            elif reply == QMessageBox.Cancel:
                return

        self.current_project = ParserModel()
        self.is_project_modified = False

        self.text_file_tab.load_content_from_project()
        self.transformation_tab.transformation_table.setRowCount(0)
        self.translation_bundle_tab.translation_table.setRowCount(0)
        self.reduction_tab.reduction_table.setRowCount(0)
        self.preprocessing_tab.load_content_from_project()
        self.clustering_tab.load_content_from_project()
        self.parsing_tab.load_content_from_project()

    def load_reductions_to_table(self):
        self.reduction_tab.reduction_table.setRowCount(0)
        for reduction in self.current_project.reductions:
            row_position = self.reduction_tab.reduction_table.rowCount()
            self.reduction_tab.reduction_table.insertRow(row_position)
            self.reduction_tab.reduction_table.setItem(row_position, 0, QTableWidgetItem(reduction['name']))
            self.reduction_tab.reduction_table.setItem(row_position, 1, QTableWidgetItem(reduction['code']))

    def load_translations_to_table(self):
        self.translation_bundle_tab.translation_table.setRowCount(0)
        for translation in self.current_project.translations:
            row_position = self.translation_bundle_tab.translation_table.rowCount()
            self.translation_bundle_tab.translation_table.insertRow(row_position)
            self.translation_bundle_tab.translation_table.setItem(row_position, 0,
                                                                  QTableWidgetItem(translation['original_word']))
            self.translation_bundle_tab.translation_table.setItem(row_position, 1,
                                                                  QTableWidgetItem(translation['replacement_word']))

    def load_transformations_to_table(self):
        self.transformation_tab.transformation_table.setRowCount(0)
        for transformation in self.current_project.transformations:
            row_position = self.transformation_tab.transformation_table.rowCount()
            self.transformation_tab.transformation_table.insertRow(row_position)
            self.transformation_tab.transformation_table.setItem(row_position, 0,
                                                                 QTableWidgetItem(transformation['name']))
            self.transformation_tab.transformation_table.setItem(row_position, 1,
                                                                 QTableWidgetItem(transformation['code']))

    def save_project(self):
        try:
            # Call save_state_to_project for each tab
            self.text_file_tab.save_state_to_project()
            self.clustering_tab.save_state_to_project()
            self.parsing_tab.save_state_to_project()

            options = QFileDialog.Options()
            file_name, _ = QFileDialog.getSaveFileName(self, "Save Project", "", "PICKLE Files (*.pkl);;All Files (*)",
                                                       options=options)
            if file_name:
                try:
                    with open(file_name, 'wb') as file:
                        pickle.dump(self.current_project, file)
                    self.is_project_modified = False
                    self.statusBar().showMessage(f'Project saved to {file_name}')
                    return True
                except Exception as e:
                    QMessageBox.critical(self, "Save Error", f"An error occurred while saving the project:\n{str(e)}")
                    return False
        except Exception as e:
            print(e)
        return False

    def load_project(self):
        options = QFileDialog.Options()
        file_name, _ = QFileDialog.getOpenFileName(self, "Open Project", "", "PICKLE Files (*.pkl);;All Files (*)",
                                                   options=options)
        if file_name:
            try:
                with open(file_name, 'rb') as file:
                    self.current_project = pickle.load(file)
                    self.is_project_modified = False

                    self.text_file_tab.load_content_from_project()
                    self.load_transformations_to_table()
                    self.load_translations_to_table()
                    self.load_reductions_to_table()
                    self.preprocessing_tab.load_content_from_project()
                    self.clustering_tab.load_content_from_project()
                    self.parsing_tab.load_content_from_project()

                    self.statusBar().showMessage(f'Project loaded from {file_name}')
            except Exception as e:
                QMessageBox.critical(self, "Load Error", f"An error occurred while loading the project:\n{str(e)}")

    def closeEvent(self, event):
        if self.is_project_modified:
            reply = QMessageBox.question(
                self, 'Save Project',
                "Do you want to save the current project before exiting?",
                QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel, QMessageBox.Cancel
            )
            if reply == QMessageBox.Yes:
                if not self.save_project():
                    event.ignore()
                    return
            elif reply == QMessageBox.Cancel:
                event.ignore()
                return

        event.accept()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    main_win = MainWindow()
    main_win.show()
    sys.exit(app.exec_())
