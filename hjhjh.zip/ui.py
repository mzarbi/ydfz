import inspect
import pickle
import sys
import json

from PyQt5.QtGui import QColor
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QTabWidget, QWidget, QVBoxLayout, QTextEdit,
    QPushButton, QFileDialog, QMessageBox, QAction, QLineEdit, QLabel, QTableWidget,
    QTableWidgetItem, QHBoxLayout, QDialog, QFormLayout, QComboBox, QDialogButtonBox, QSplitter, QListWidget,
    QTextBrowser, QTreeWidget, QTreeWidgetItem, QAbstractItemView
)
from PyQt5.QtCore import Qt
from pyqode.core.api import CodeEdit
from pyqode.python.backend import server
from pyqode.python.widgets import PyCodeEdit
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.cluster import KMeans
from sklearn.pipeline import FeatureUnion
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.metrics import silhouette_score
import numpy as np
import pandas as pd

import logging

# Set the logging level for pyqode to CRITICAL to suppress less severe messages
logging.getLogger('pyqode').setLevel(logging.CRITICAL)

# If necessary, apply this to other relevant loggers as well
logging.getLogger('pyqode.core.backend.server').setLevel(logging.CRITICAL)
logging.getLogger('pyqode.python.backend').setLevel(logging.CRITICAL)

# Constants
N = 2  # Number of previous and next lines to consider


# Example transformations (as placeholders)
def uppercase_transformation(current_line, prev_lines, next_lines):
    return current_line.upper()


def reverse_transformation(current_line, prev_lines, next_lines):
    return current_line[::-1]


def transformation(current_line, prev_lines, next_lines):
    return current_line


def strip_transformation(current_line, prev_lines, next_lines):
    return current_line.strip()


TRANSFORMATIONS = {
    "Transformation": transformation,
    "Uppercase": uppercase_transformation,
    "Reverse": reverse_transformation,
    "Strip": strip_transformation
}

FEATURE_EXTRACTORS = {
    "Length Feature": """
class LengthFeatureExtractor(BaseEstimator, TransformerMixin):
    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return np.array([[len(text)] for text in X])
""",
    "Word Existence Feature": """
class WordExistenceFeatureExtractor(BaseEstimator, TransformerMixin):
    def __init__(self):
        self.words = []

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return np.array([[1 if word in text else 0 for word in self.words] for text in X])
""",
    "Custom Feature (Empty Template)": """
class CustomFeatureExtractor(BaseEstimator, TransformerMixin):
    def __init__(self):
        # Initialize any parameters here
        pass

    def fit(self, X, y=None):
        # Implement fitting logic if necessary
        return self

    def transform(self, X):
        # Implement the feature extraction logic here
        # Return a numpy array with the extracted features
        return np.array([[0] for _ in X])
"""
}


class ParserProject:
    def __init__(self):
        self.loaded_filename = None
        self.text_content = ""
        self.transformations = []
        self.translations = []
        self.reductions = []
        self.preprocessing_order = []
        self.feature_extractors = []
        self.clustering_model = None
        self.cluster_parsers = {}  # New attribute to store parser functions

    def to_dict(self):
        return {
            "loaded_filename": self.loaded_filename,
            "text_content": self.text_content,
            "transformations": self.transformations,
            "translations": self.translations,
            "reductions": self.reductions,
            "preprocessing_order": self.preprocessing_order,
            "feature_extractors": self.feature_extractors,
            "cluster_parsers": self.cluster_parsers  # Save parser functions
        }

    def from_dict(self, data):
        self.loaded_filename = data.get("loaded_filename", None)
        self.text_content = data.get("text_content", "")
        self.transformations = data.get("transformations", [])
        self.translations = data.get("translations", [])
        self.reductions = data.get("reductions", [])
        self.preprocessing_order = data.get("preprocessing_order", [])
        self.feature_extractors = data.get("feature_extractors", [])
        self.clustering_model = data.get("clustering_model", None)
        self.cluster_parsers = data.get("cluster_parsers", {})


class WeightedFeatureExtractor(BaseEstimator, TransformerMixin):
    def __init__(self, transformer, weight=100.0):
        self.transformer = transformer
        self.weight = weight

    def fit(self, X, y=None):
        self.transformer.fit(X, y)
        return self

    def transform(self, X):
        return self.transformer.transform(X) * self.weight


class TextClusterParser:
    def __init__(self, n_clusters=10, pca_variance=0.95, random_state=42):
        self.pca_variance = pca_variance
        self.n_clusters = n_clusters
        self.random_state = random_state
        self.additional_features = []
        self.feature_union = None
        self.fitted = False
        self.labels = None
        self.tagged_lines = None
        self.silhouette_avg = None
        self.initialize()

    def initialize(self):
        self.vectorizer = TfidfVectorizer()
        self.reducer = TruncatedSVD(n_components=int(self.pca_variance * 100))
        self.clusterer = KMeans(n_clusters=self.n_clusters, random_state=self.random_state)

    def add_feature_extractor(self, feature_name, transformer, weight=100.0):
        self.additional_features.append(
            (feature_name, WeightedFeatureExtractor(transformer, weight))
        )

    def fit(self, lines):
        combined_data = pd.DataFrame({'Line': lines})
        self.feature_union = FeatureUnion(self.additional_features + [('vectorizer', self.vectorizer)])

        # Step 1: Feature Extraction
        X_features = self.feature_union.fit_transform(combined_data['Line'])

        # Step 2: Dimensionality Reduction
        X_pca = self.reducer.fit_transform(X_features)

        # Step 3: Clustering
        self.labels = self.clusterer.fit_predict(X_pca)
        self.silhouette_avg = silhouette_score(X_pca, self.labels)

        # Step 4: Tagging and Result Display
        self.tagged_lines = pd.DataFrame({'Line': lines, 'Cluster': self.labels})
        self.fitted = True

        return self.tagged_lines

    def predict(self, new_lines):
        if not self.fitted:
            raise ValueError("The model must be fitted before predicting.")

        new_X_features = self.feature_union.transform(pd.DataFrame({'Line': new_lines})['Line'])
        new_X_pca = self.reducer.transform(new_X_features)
        new_labels = self.clusterer.predict(new_X_pca)

        return pd.DataFrame({'Line': new_lines, 'Cluster': new_labels})

    def inspect_cluster(self, cluster_number):
        if not self.fitted:
            raise ValueError("The model must be fitted before inspecting clusters.")
        return self.tagged_lines[self.tagged_lines['Cluster'] == cluster_number]['Line'].tolist()


def try_(show_message=True):
    def decorator(func):
        def wrapper(self, *args, **kwargs):
            try:
                return func(self, *args, **kwargs)
            except Exception as e:
                # Log the error
                print(f"Exception occurred in {func.__name__}: {e}", exc_info=True)

                if show_message:
                    # Create a QMessageBox to display the error
                    msg_box = QMessageBox()
                    msg_box.setIcon(QMessageBox.Critical)
                    msg_box.setWindowTitle("Error")
                    msg_box.setText(f"An error occurred in {func.__name__}: {e}")
                    msg_box.setStandardButtons(QMessageBox.Ok)
                    msg_box.exec_()

        return wrapper

    return decorator

class ClusteringTab(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window
        self.cluster_parser = TextClusterParser()
        self.initUI()

    def initUI(self):
        main_layout = QVBoxLayout()

        # Create a horizontal layout for the two text areas
        text_area_layout = QHBoxLayout()

        # Preprocessed text preview
        self.preprocessed_text_area = QTextEdit(self)
        self.preprocessed_text_area.setReadOnly(True)
        text_area_layout.addWidget(self.preprocessed_text_area)

        # Tagged text preview
        self.tagged_text_area = QTextBrowser(self)
        text_area_layout.addWidget(self.tagged_text_area)

        # Add the horizontal layout to the main layout
        main_layout.addLayout(text_area_layout)

        tables_layout = QHBoxLayout()

        # QTableWidget for storing feature extractors
        self.feature_table = QTableWidget(0, 3, self)
        self.feature_table.setHorizontalHeaderLabels(["Feature Name", "Weight", "Code"])
        tables_layout.addWidget(self.feature_table)

        # QTableWidget for displaying clusters and colors
        self.cluster_table = QTableWidget(0, 2, self)
        self.cluster_table.setHorizontalHeaderLabels(["Cluster Label", "Color"])
        tables_layout.addWidget(self.cluster_table)

        main_layout.addLayout(tables_layout)

        # Feature Extractor Toolbox
        toolbox_layout = QHBoxLayout()

        self.add_button = QPushButton("Add Feature Extractor", self)
        self.add_button.clicked.connect(self.add_feature_extractor)
        toolbox_layout.addWidget(self.add_button)

        self.edit_button = QPushButton("Edit Feature Extractor", self)
        self.edit_button.clicked.connect(self.edit_feature_extractor)
        toolbox_layout.addWidget(self.edit_button)

        self.delete_button = QPushButton("Delete Feature Extractor", self)
        self.delete_button.clicked.connect(self.delete_feature_extractor)
        toolbox_layout.addWidget(self.delete_button)

        self.pos_button = QPushButton("POS", self)
        self.pos_button.clicked.connect(self.add_pos_feature_extractor)
        toolbox_layout.addWidget(self.pos_button)

        self.test_button = QPushButton("Test Clustering", self)
        self.test_button.clicked.connect(self.run_clustering)
        toolbox_layout.addWidget(self.test_button)

        self.raw_text_button = QPushButton("Show Preprocessed Text", self)
        self.raw_text_button.clicked.connect(self.show_raw_text)
        toolbox_layout.addWidget(self.raw_text_button)

        self.n_clusters_label = QLabel("Number of Clusters:")
        toolbox_layout.addWidget(self.n_clusters_label)

        self.n_clusters_edit = QLineEdit(self)
        self.n_clusters_edit.setText(str(self.cluster_parser.n_clusters))
        toolbox_layout.addWidget(self.n_clusters_edit)

        self.cluster_filter_label = QLabel("Filter Clusters (comma-separated):")
        toolbox_layout.addWidget(self.cluster_filter_label)

        self.cluster_filter_edit = QLineEdit(self)
        toolbox_layout.addWidget(self.cluster_filter_edit)

        main_layout.addLayout(toolbox_layout)
        self.setLayout(main_layout)

    def save_state_to_project(self):
        """Save the current state to the project."""
        self.main_window.current_project.feature_extractors = [
            {
                "name": self.feature_table.item(row, 0).text(),
                "weight": float(self.feature_table.item(row, 1).text()),
                "code": self.feature_table.item(row, 2).text(),
            }
            for row in range(self.feature_table.rowCount())
        ]

        # Save the clustering model (except feature extractors) using pickle
        self.main_window.current_project.clustering_model = pickle.dumps({
            "vectorizer": self.cluster_parser.vectorizer,
            "reducer": self.cluster_parser.reducer,
            "clusterer": self.cluster_parser.clusterer,
            "n_clusters": self.cluster_parser.n_clusters,
            "pca_variance": self.cluster_parser.pca_variance,
            "random_state": self.cluster_parser.random_state,
            "fitted": self.cluster_parser.fitted,
            "labels": self.cluster_parser.labels,
            "tagged_lines": self.cluster_parser.tagged_lines,
            "silhouette_avg": self.cluster_parser.silhouette_avg
        })

    def load_content_from_project(self):
        """Load the content from the current project."""
        self.feature_table.setRowCount(0)
        for extractor in self.main_window.current_project.feature_extractors:
            row_position = self.feature_table.rowCount()
            self.feature_table.insertRow(row_position)
            self.feature_table.setItem(row_position, 0, QTableWidgetItem(extractor["name"]))
            self.feature_table.setItem(row_position, 1, QTableWidgetItem(str(extractor["weight"])))
            self.feature_table.setItem(row_position, 2, QTableWidgetItem(extractor["code"]))

            # Recreate the feature extractor
            transformer = self.create_transformer(extractor["code"])
            self.cluster_parser.add_feature_extractor(extractor["name"], transformer, extractor["weight"])

        # Load the clustering model using pickle
        if self.main_window.current_project.clustering_model:
            model_data = pickle.loads(self.main_window.current_project.clustering_model)
            self.cluster_parser.vectorizer = model_data["vectorizer"]
            self.cluster_parser.reducer = model_data["reducer"]
            self.cluster_parser.clusterer = model_data["clusterer"]
            self.cluster_parser.n_clusters = model_data["n_clusters"]
            self.cluster_parser.pca_variance = model_data["pca_variance"]
            self.cluster_parser.random_state = model_data["random_state"]
            self.cluster_parser.fitted = model_data["fitted"]
            self.cluster_parser.labels = model_data["labels"]
            self.cluster_parser.tagged_lines = model_data["tagged_lines"]
            self.cluster_parser.silhouette_avg = model_data["silhouette_avg"]

            self.n_clusters_edit.setText(model_data["n_clusters"])

    def create_transformer(self, feature_code):
        """Dynamically create a transformer from the provided code."""
        local_vars = {}
        exec(feature_code, globals(), local_vars)
        transformer_class_name = list(local_vars.keys())[0]
        return local_vars[transformer_class_name]()

    def display_clusters(self, tagged_lines, cluster_filter_text):
        self.cluster_table.setRowCount(0)  # Clear existing data
        clusters = tagged_lines['Cluster'].unique()

        if cluster_filter_text:
            cluster_filter = list(map(int, cluster_filter_text.split(',')))
            tagged_lines = tagged_lines[tagged_lines['Cluster'].isin(cluster_filter)]

        dc = {}
        for cluster_label in clusters:
            row_position = self.cluster_table.rowCount()
            self.cluster_table.insertRow(row_position)

            # Cluster label
            self.cluster_table.setItem(row_position, 0, QTableWidgetItem(str(cluster_label)))

            # Color associated with the cluster
            color = QColor.fromHsv((cluster_label * 40) % 360, 255, 255, 150).name()
            color_item = QTableWidgetItem()
            color_item.setBackground(QColor(color))
            self.cluster_table.setItem(row_position, 1, color_item)
            dc[str(cluster_label)] = color

        # Display colored text in tagged_text_area
        self.tagged_text_area.clear()
        for _, row in tagged_lines.iterrows():
            colored_text = f'<p style="background-color:{dc[str(row["Cluster"])]}">{row["Line"]}</p>'
            self.tagged_text_area.append(colored_text)

    def add_pos_feature_extractor(self):
        selected_text = self.preprocessed_text_area.textCursor().selectedText()
        if selected_text:
            # Automatically create a feature extractor with the selected text
            feature_code_template = """
class WordExistenceFeatureExtractor(BaseEstimator, TransformerMixin):
    def __init__(self):
        self.words = ["WORD_EXAMPLE"]

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return np.array([[1 if word in text else 0 for word in self.words] for text in X])
"""
            feature_code = feature_code_template.replace("WORD_EXAMPLE", selected_text)
            dialog = FeatureExtractorDialog(self, feature_name=f"Word Existence ({selected_text})",
                                            feature_code=feature_code)
            if dialog.exec_() == QDialog.Accepted:
                row_position = self.feature_table.rowCount()
                self.feature_table.insertRow(row_position)
                self.feature_table.setItem(row_position, 0, QTableWidgetItem(dialog.feature_name))
                self.feature_table.setItem(row_position, 1, QTableWidgetItem(str(dialog.weight)))
                self.feature_table.setItem(row_position, 2, QTableWidgetItem(dialog.feature_code))

                transformer = self.create_transformer(dialog.feature_code)
                self.cluster_parser.add_feature_extractor(dialog.feature_name, transformer, dialog.weight)
                self.main_window.is_project_modified = True
        else:
            QMessageBox.warning(self, "No Text Selected", "Please select some text in the Preprocessed Text area.")

    def add_feature_extractor(self):
        dialog = FeatureExtractorDialog(self)
        if dialog.exec_() == QDialog.Accepted:
            row_position = self.feature_table.rowCount()
            self.feature_table.insertRow(row_position)
            self.feature_table.setItem(row_position, 0, QTableWidgetItem(dialog.feature_name))
            self.feature_table.setItem(row_position, 1, QTableWidgetItem(str(dialog.weight)))
            self.feature_table.setItem(row_position, 2, QTableWidgetItem(dialog.feature_code))

            transformer = self.create_transformer(dialog.feature_code)
            self.cluster_parser.add_feature_extractor(dialog.feature_name, transformer, dialog.weight)
            self.main_window.is_project_modified = True

    def edit_feature_extractor(self):
        current_row = self.feature_table.currentRow()
        if current_row >= 0:
            feature_name_item = self.feature_table.item(current_row, 0)
            weight_item = self.feature_table.item(current_row, 1)
            code_item = self.feature_table.item(current_row, 2)

            dialog = FeatureExtractorDialog(
                self, feature_name=feature_name_item.text(),
                feature_code=code_item.text(), weight=float(weight_item.text())
            )
            if dialog.exec_() == QDialog.Accepted:
                self.feature_table.setItem(current_row, 0, QTableWidgetItem(dialog.feature_name))
                self.feature_table.setItem(current_row, 1, QTableWidgetItem(str(dialog.weight)))
                self.feature_table.setItem(current_row, 2, QTableWidgetItem(dialog.feature_code))

                transformer = self.create_transformer(dialog.feature_code)
                self.cluster_parser.additional_features[current_row] = (
                    dialog.feature_name, WeightedFeatureExtractor(transformer, dialog.weight)
                )
                self.main_window.is_project_modified = True

    def delete_feature_extractor(self):
        current_row = self.feature_table.currentRow()
        if current_row >= 0:
            self.feature_table.removeRow(current_row)
            del self.cluster_parser.additional_features[current_row]
            self.main_window.is_project_modified = True

    def run_clustering(self):
        self.cluster_parser.n_clusters = int(self.n_clusters_edit.text())
        self.cluster_parser.initialize()
        preprocessed_text = self.get_preprocessed_text()
        text_lines = preprocessed_text.splitlines()

        # Display the preprocessed text
        self.preprocessed_text_area.setPlainText(preprocessed_text)

        # Fit and get the tagged lines
        tagged_lines = self.cluster_parser.fit(text_lines)

        # Filter clusters based on user input
        cluster_filter_text = self.cluster_filter_edit.text()

        # Display clusters
        self.display_clusters(tagged_lines, cluster_filter_text)

    def display_clusters2(self, tagged_lines):
        colored_text = ""
        for _, row in tagged_lines.iterrows():
            color = QColor.fromHsv((row['Cluster'] * 40) % 360, 255, 255, 150).name()
            colored_text += f'<p style="background-color:{color}">{row["Line"]}</p>'
        self.tagged_text_area.setHtml(colored_text)

    def show_raw_text(self):
        preprocessed_text = self.get_preprocessed_text()
        self.preprocessed_text_area.setPlainText(preprocessed_text)

    def get_preprocessed_text(self):
        # Execute the preprocessing steps defined in the PreprocessingTab
        preprocessed_text = self.main_window.preprocessing_tab.execute_operations()
        return "\n".join(preprocessed_text)


class FeatureExtractorDialog(QDialog):
    def __init__(self, parent=None, feature_name="", feature_code="", weight=100.0, word_example="WORD_EXAMPLE"):
        super().__init__(parent)
        self.feature_name = feature_name
        self.feature_code = feature_code
        self.weight = weight
        self.word_example = word_example
        self.initUI()

    def initUI(self):
        layout = QFormLayout()

        # LineEdit for feature name
        self.feature_name_edit = QLineEdit(self)
        self.feature_name_edit.setText(self.feature_name)
        layout.addRow("Feature Name:", self.feature_name_edit)

        # ComboBox for selecting a predefined template
        self.template_combo = QComboBox(self)
        self.template_combo.addItems(FEATURE_EXTRACTORS.keys())
        self.template_combo.currentIndexChanged.connect(self.load_template)
        layout.addRow("Select Template:", self.template_combo)

        # PyQod editor for Python code editing
        self.code_editor = PyCodeEdit(self)
        self.code_editor.backend.start(server.__file__)
        self.code_editor.setPlainText(self.feature_code)
        layout.addRow("Feature Code:", self.code_editor)

        # LineEdit for weight
        self.weight_edit = QLineEdit(self)
        self.weight_edit.setText(str(self.weight))
        layout.addRow("Weight:", self.weight_edit)

        # Dialog buttons
        self.button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        layout.addWidget(self.button_box)

        self.setLayout(layout)

    def load_template(self):
        template_name = self.template_combo.currentText()
        if template_name in FEATURE_EXTRACTORS:
            template_code = FEATURE_EXTRACTORS[template_name]
            self.code_editor.setPlainText(template_code.replace("WORD_EXAMPLE", self.word_example))

    def accept(self):
        self.feature_name = self.feature_name_edit.text()
        self.feature_code = self.code_editor.toPlainText()
        self.weight = float(self.weight_edit.text())
        super().accept()

    def reject(self):
        super().reject()


class PreprocessingTab(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        # Preview area
        self.preview_text_area = QTextEdit(self)
        self.preview_text_area.setReadOnly(True)
        layout.addWidget(self.preview_text_area)

        # Table for specifying the order of operations
        self.order_table = QTableWidget(0, 2, self)
        self.order_table.setHorizontalHeaderLabels(["Operation Type", "Name"])
        layout.addWidget(self.order_table)

        # Toolbox for managing the order
        toolbox_layout = QHBoxLayout()

        self.add_button = QPushButton("Add Operation", self)
        self.add_button.clicked.connect(self.add_operation)
        toolbox_layout.addWidget(self.add_button)

        self.remove_button = QPushButton("Remove Operation", self)
        self.remove_button.clicked.connect(self.remove_operation)
        toolbox_layout.addWidget(self.remove_button)

        self.move_up_button = QPushButton("Move Up", self)
        self.move_up_button.clicked.connect(self.move_operation_up)
        toolbox_layout.addWidget(self.move_up_button)

        self.move_down_button = QPushButton("Move Down", self)
        self.move_down_button.clicked.connect(self.move_operation_down)
        toolbox_layout.addWidget(self.move_down_button)

        self.execute_button = QPushButton("Execute", self)
        self.execute_button.clicked.connect(self.execute_operations)
        toolbox_layout.addWidget(self.execute_button)

        layout.addLayout(toolbox_layout)
        self.setLayout(layout)

    def add_operation(self):
        dialog = AddOperationDialog(self.main_window)
        if dialog.exec_() == QDialog.Accepted:
            operation_type, name = dialog.get_selected_operation()

            # Add the selected operation to the table
            row_position = self.order_table.rowCount()
            self.order_table.insertRow(row_position)
            self.order_table.setItem(row_position, 0, QTableWidgetItem(operation_type))
            self.order_table.setItem(row_position, 1, QTableWidgetItem(name))

            self.main_window.current_project.preprocessing_order.append({
                "type": operation_type,
                "name": name
            })
            self.main_window.is_project_modified = True

    def remove_operation(self):
        current_row = self.order_table.currentRow()
        if current_row >= 0:
            self.order_table.removeRow(current_row)
            del self.main_window.current_project.preprocessing_order[current_row]
            self.main_window.is_project_modified = True

    def move_operation_up(self):
        current_row = self.order_table.currentRow()
        if current_row > 0:
            self.order_table.insertRow(current_row - 1)
            for col in range(self.order_table.columnCount()):
                self.order_table.setItem(current_row - 1, col, self.order_table.takeItem(current_row + 1, col))
            self.order_table.removeRow(current_row + 1)
            self.order_table.setCurrentCell(current_row - 1, 0)

            # Move operation in preprocessing_order
            self.main_window.current_project.preprocessing_order.insert(current_row - 1,
                                                                        self.main_window.current_project.preprocessing_order.pop(
                                                                            current_row))
            self.main_window.is_project_modified = True

    def move_operation_down(self):
        current_row = self.order_table.currentRow()
        if current_row < self.order_table.rowCount() - 1:
            self.order_table.insertRow(current_row + 2)
            for col in range(self.order_table.columnCount()):
                self.order_table.setItem(current_row + 2, col, self.order_table.takeItem(current_row, col))
            self.order_table.removeRow(current_row)
            self.order_table.setCurrentCell(current_row + 1, 0)

            # Move operation in preprocessing_order
            self.main_window.current_project.preprocessing_order.insert(current_row + 1,
                                                                        self.main_window.current_project.preprocessing_order.pop(
                                                                            current_row))
            self.main_window.is_project_modified = True

    def execute_operations(self):
        text_lines = self.main_window.current_project.text_content.splitlines()

        for operation in self.main_window.current_project.preprocessing_order:
            operation_type = operation["type"]
            name = operation["name"]

            if operation_type == "Transformation":
                op = next((t for t in self.main_window.current_project.transformations if t['name'] == name), None)
                if op:
                    text_lines = self.apply_transformation(op, text_lines)
            elif operation_type == "Reduction":
                op = next((r for r in self.main_window.current_project.reductions if r['name'] == name), None)
                if op:
                    text_lines = self.apply_reduction(op, text_lines)
            elif operation_type == "Translation":
                op = next((tr for tr in self.main_window.current_project.translations if tr['original_word'] == name),
                          None)
                if op:
                    text_lines = self.apply_translation(op, text_lines)

        # Display the final output in the preview area
        self.preview_text_area.setText("\n".join(text_lines))
        return text_lines

    def apply_transformation(self, transformation, text_lines):
        transformed_lines = []
        transformation_func = self.evaluate_code(transformation['code'])

        if not transformation_func:
            QMessageBox.critical(self, "Transformation Error",
                                 f"Transformation function {transformation['name']} could not be evaluated.")
            return text_lines

        for i in range(len(text_lines)):
            current_line = text_lines[i]
            prev_lines = text_lines[max(0, i - N):i]
            next_lines = text_lines[i + 1:min(len(text_lines), i + 1 + N)]
            transformed_line = transformation_func(current_line, prev_lines, next_lines)
            transformed_lines.append(transformed_line)

        return transformed_lines

    def apply_reduction(self, reduction, text_lines):
        reduced_lines = []
        reduction_func = self.evaluate_code(reduction['code'])

        if not reduction_func:
            QMessageBox.critical(self, "Reduction Error",
                                 f"Reduction function {reduction['name']} could not be evaluated.")
            return text_lines

        for i in range(len(text_lines)):
            current_line = text_lines[i]
            prev_lines = text_lines[max(0, i - N):i]
            next_lines = text_lines[i + 1:min(len(text_lines), i + 1 + N)]
            if reduction_func(current_line, prev_lines, next_lines):
                reduced_lines.append(current_line)

        return reduced_lines

    def apply_translation(self, translation, text_lines):
        return [line.replace(translation['original_word'], translation['replacement_word']) for line in text_lines]

    def evaluate_code(self, code):
        """Evaluate the provided code as a function."""
        try:
            exec(code, globals())
            return eval('reduction_function')
        except Exception as e:
            QMessageBox.critical(self, "Code Error", f"Error in the code:\n{str(e)}")
            return None

    def load_content_from_project(self):
        """Load the content of the order table from the current project."""
        self.order_table.setRowCount(0)
        for operation in self.main_window.current_project.preprocessing_order:
            row_position = self.order_table.rowCount()
            self.order_table.insertRow(row_position)
            self.order_table.setItem(row_position, 0, QTableWidgetItem(operation["type"]))
            self.order_table.setItem(row_position, 1, QTableWidgetItem(operation["name"]))


class AddOperationDialog(QDialog):
    def __init__(self, main_window):
        super().__init__(main_window)
        self.main_window = main_window
        self.initUI()

    @try_(show_message=True)
    def initUI(self):
        layout = QVBoxLayout()

        self.operation_type_combo = QComboBox(self)
        self.operation_type_combo.addItems(["Transformation", "Reduction", "Translation"])
        self.operation_type_combo.currentIndexChanged.connect(self.update_operation_list)
        layout.addWidget(self.operation_type_combo)

        self.operation_list = QListWidget(self)
        layout.addWidget(self.operation_list)

        self.update_operation_list()

        self.button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        layout.addWidget(self.button_box)

        self.setLayout(layout)

    @try_(show_message=True)
    def update_operation_list(self):
        self.operation_list.clear()
        operation_type = self.operation_type_combo.currentText()

        if operation_type == "Transformation":
            for transformation in self.main_window.current_project.transformations:
                self.operation_list.addItem(transformation['name'])
        elif operation_type == "Reduction":
            for reduction in self.main_window.current_project.reductions:
                self.operation_list.addItem(reduction['name'])
        elif operation_type == "Translation":
            for translation in self.main_window.current_project.translations:
                self.operation_list.addItem(translation['original_word'])

    def get_selected_operation(self):
        operation_type = self.operation_type_combo.currentText()
        name = self.operation_list.currentItem().text()
        return operation_type, name


class TransformationTab(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        # Preview area
        self.preview_text_area = QTextEdit(self)
        self.preview_text_area.setReadOnly(True)
        layout.addWidget(self.preview_text_area)

        # Table for storing transformations
        self.transformation_table = QTableWidget(0, 2, self)
        self.transformation_table.setHorizontalHeaderLabels(["Transformation", "Details"])
        layout.addWidget(self.transformation_table)

        # Transformation Toolbox
        toolbox_layout = QHBoxLayout()

        self.add_button = QPushButton("Add Transformation", self)
        self.add_button.clicked.connect(self.add_transformation)
        toolbox_layout.addWidget(self.add_button)

        self.edit_button = QPushButton("Edit Transformation", self)
        self.edit_button.clicked.connect(self.edit_transformation)
        toolbox_layout.addWidget(self.edit_button)

        self.delete_button = QPushButton("Delete Transformation", self)
        self.delete_button.clicked.connect(self.delete_transformation)
        toolbox_layout.addWidget(self.delete_button)

        self.test_button = QPushButton("Test Transformation", self)
        self.test_button.clicked.connect(self.test_transformation)
        toolbox_layout.addWidget(self.test_button)

        self.test_all_button = QPushButton("Test All", self)
        self.test_all_button.clicked.connect(self.test_all_transformations)
        toolbox_layout.addWidget(self.test_all_button)

        layout.addLayout(toolbox_layout)
        self.setLayout(layout)

    def add_transformation(self):
        dialog = TransformationDialog(self)
        if dialog.exec_() == QDialog.Accepted:
            transformation_label = dialog.transformation_name
            transformation_code = dialog.transformation_code

            # Add transformation to the table and project
            row_position = self.transformation_table.rowCount()
            self.transformation_table.insertRow(row_position)
            self.transformation_table.setItem(row_position, 0, QTableWidgetItem(transformation_label))
            self.transformation_table.setItem(row_position, 1, QTableWidgetItem(transformation_code))

            self.main_window.current_project.transformations.append({
                "label": transformation_label,
                "code": transformation_code
            })
            self.main_window.is_project_modified = True

    def edit_transformation(self):
        current_row = self.transformation_table.currentRow()
        if current_row >= 0:
            transformation_label = self.transformation_table.item(current_row, 0).text()
            transformation_code = self.transformation_table.item(current_row, 1).text()

            dialog = TransformationDialog(self, transformation_name=transformation_label,
                                          transformation_code=transformation_code)
            if dialog.exec_() == QDialog.Accepted:
                updated_label = dialog.transformation_name
                updated_code = dialog.transformation_code

                # Update the table and the project with the edited transformation
                self.transformation_table.setItem(current_row, 0, QTableWidgetItem(updated_label))
                self.transformation_table.setItem(current_row, 1, QTableWidgetItem(updated_code))

                self.main_window.current_project.transformations[current_row] = {
                    "label": updated_label,
                    "code": updated_code
                }
                self.main_window.is_project_modified = True

    def delete_transformation(self):
        current_row = self.transformation_table.currentRow()
        if current_row >= 0:
            self.transformation_table.removeRow(current_row)
            del self.main_window.current_project.transformations[current_row]
            self.main_window.is_project_modified = True

    def test_transformation(self):
        current_row = self.transformation_table.currentRow()
        if current_row >= 0:
            transformation = self.main_window.current_project.transformations[current_row]
            self.apply_transformation(transformation)

    def test_all_transformations(self):
        for transformation in self.main_window.current_project.transformations:
            self.apply_transformation(transformation)

    def apply_transformation(self, transformation):
        text_lines = self.main_window.current_project.text_content.splitlines()
        transformed_lines = []
        transformation_code = transformation['code']

        # Dynamically create and execute the transformation function from the code
        local_vars = {}
        try:
            exec(transformation_code, {}, local_vars)
            # Find the transformation function (assuming there's only one)
            transformation_func = next((v for k, v in local_vars.items() if callable(v)), None)
        except Exception as e:
            QMessageBox.critical(self, "Transformation Error", f"Error in transformation code: {str(e)}")
            return

        if not transformation_func:
            QMessageBox.critical(self, "Transformation Error", "No valid transformation function found in the code.")
            return

        for i in range(len(text_lines)):
            current_line = text_lines[i]
            prev_lines = text_lines[max(0, i - N):i]
            next_lines = text_lines[i + 1:min(len(text_lines), i + 1 + N)]
            try:
                transformed_line = transformation_func(current_line, prev_lines, next_lines)
                transformed_lines.append(transformed_line)
            except Exception as e:
                QMessageBox.critical(self, "Transformation Error", f"Error applying transformation: {str(e)}")
                return

        self.preview_text_area.setText("\n".join(transformed_lines))


class TransformationDialog(QDialog):
    def __init__(self, parent=None, transformation_name="", transformation_code=""):
        super().__init__(parent)
        self.transformation_name = transformation_name
        self.transformation_code = transformation_code
        self.original_code = transformation_code
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Edit Transformation" if self.transformation_name else "Add Transformation")
        self.resize(800, 300)  # Set a larger size for the dialog

        layout = QFormLayout()

        # ComboBox for transformation selection (disabled if editing)
        self.transformation_combo = QComboBox(self)
        self.transformation_combo.addItems(TRANSFORMATIONS.keys())
        layout.addRow("Select Transformation:", self.transformation_combo)

        # PyCodeEdit for Python code editing
        self.code_editor = PyCodeEdit(self)
        self.code_editor.backend.start(server.__file__)

        layout.addRow("Transformation Code:", self.code_editor)

        # Dialog buttons
        self.button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        layout.addWidget(self.button_box)

        self.setLayout(layout)

        # If editing an existing transformation, load its code
        if self.transformation_name:
            self.transformation_combo.setCurrentText(self.transformation_name)
            self.transformation_combo.setEnabled(False)  # Disable combo box when editing
            self.code_editor.setPlainText(self.transformation_code)
            self.original_code = self.transformation_code
        else:
            self.transformation_combo.currentTextChanged.connect(self.load_transformation_code)
            # Load the initial transformation code
            self.load_transformation_code(self.transformation_combo.currentText())

    def load_transformation_code(self, transformation_name):
        """Load the source code of the selected transformation."""
        if transformation_name in TRANSFORMATIONS:
            try:
                source_code = inspect.getsource(TRANSFORMATIONS[transformation_name])
                self.code_editor.setPlainText(source_code)
                self.original_code = source_code
                self.transformation_name = transformation_name
            except OSError as e:
                QMessageBox.critical(self, "Error", f"Could not retrieve source code: {str(e)}")

    def accept(self):
        current_code = self.code_editor.toPlainText()
        if current_code != self.original_code:
            # Code has been modified, assign a new name if not already editing
            if not self.transformation_name:
                base_name = self.transformation_combo.currentText() + "_Custom"
                new_name = self.generate_new_name(base_name)
                self.transformation_name = new_name
        self.transformation_code = current_code
        super().accept()

    def generate_new_name(self, base_name):
        """Generate a new transformation name if the code is customized."""
        existing_names = [trans['name'] for trans in self.parent().main_window.current_project.transformations]
        new_name = base_name
        counter = 1
        while new_name in existing_names:
            new_name = f"{base_name}_{counter}"
            counter += 1
        return new_name

    def reject(self):
        super().reject()


class ReductionTab(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        # Create a splitter to hold the preview area and the table
        splitter = QSplitter(Qt.Horizontal)

        # Preview area
        self.preview_text_area = QTextEdit(self)
        self.preview_text_area.setReadOnly(True)
        splitter.addWidget(self.preview_text_area)

        # Table for storing reductions
        self.reduction_table = QTableWidget(0, 2, self)
        self.reduction_table.setHorizontalHeaderLabels(["Reduction Name", "Function"])
        splitter.addWidget(self.reduction_table)

        # Set the initial sizes for the splitter
        splitter.setStretchFactor(0, 7)  # 70% for the preview area
        splitter.setStretchFactor(1, 3)  # 30% for the table

        layout.addWidget(splitter)

        # Reduction Toolbox
        toolbox_layout = QHBoxLayout()

        self.show_raw_button = QPushButton("Show RAW Text", self)
        self.show_raw_button.clicked.connect(self.show_raw_text)
        toolbox_layout.addWidget(self.show_raw_button)

        self.add_button = QPushButton("Add Reduction", self)
        self.add_button.clicked.connect(self.add_reduction)
        toolbox_layout.addWidget(self.add_button)

        self.pos_exclusion_button = QPushButton("POS Exclusion", self)
        self.pos_exclusion_button.clicked.connect(self.add_pos_exclusion)
        toolbox_layout.addWidget(self.pos_exclusion_button)

        self.delete_button = QPushButton("Delete Reduction", self)
        self.delete_button.clicked.connect(self.delete_reduction)
        toolbox_layout.addWidget(self.delete_button)

        self.edit_button = QPushButton("Edit Reduction", self)
        self.edit_button.clicked.connect(self.edit_reduction)
        toolbox_layout.addWidget(self.edit_button)

        self.test_button = QPushButton("Test Reduction", self)
        self.test_button.clicked.connect(self.test_reduction)
        toolbox_layout.addWidget(self.test_button)

        self.test_all_button = QPushButton("Test All", self)
        self.test_all_button.clicked.connect(self.test_all_reductions)
        toolbox_layout.addWidget(self.test_all_button)

        layout.addLayout(toolbox_layout)
        self.setLayout(layout)

    def show_raw_text(self):
        """Display the raw text from the project in the preview area."""
        raw_text = self.main_window.current_project.text_content
        self.preview_text_area.setText(raw_text)

    def add_reduction(self):
        dialog = ReductionDialog(self)
        if dialog.exec_() == QDialog.Accepted:
            reduction_name = dialog.reduction_name
            reduction_code = dialog.reduction_code

            # Add reduction to the table and project
            row_position = self.reduction_table.rowCount()
            self.reduction_table.insertRow(row_position)
            self.reduction_table.setItem(row_position, 0, QTableWidgetItem(reduction_name))
            self.reduction_table.setItem(row_position, 1, QTableWidgetItem(reduction_code))

            self.main_window.current_project.reductions.append({
                "name": reduction_name,
                "code": reduction_code
            })
            self.main_window.is_project_modified = True

    def add_pos_exclusion(self):
        selected_text = self.preview_text_area.textCursor().selectedText()
        dialog = ReductionDialog(self, reduction_code=self.get_pos_exclusion_template(selected_text))
        if dialog.exec_() == QDialog.Accepted:
            reduction_name = dialog.reduction_name
            reduction_code = dialog.reduction_code

            # Add reduction to the table and project
            row_position = self.reduction_table.rowCount()
            self.reduction_table.insertRow(row_position)
            self.reduction_table.setItem(row_position, 0, QTableWidgetItem(reduction_name))
            self.reduction_table.setItem(row_position, 1, QTableWidgetItem(reduction_code))

            self.main_window.current_project.reductions.append({
                "name": reduction_name,
                "code": reduction_code
            })
            self.main_window.is_project_modified = True

    def get_pos_exclusion_template(self, selected_text=""):
        """Return a template function for POS exclusion."""
        return f"""def reduction_function(current_line, prev_lines, next_lines):
    # This function excludes lines containing the specified string
    exclusion_string = "{selected_text}"
    return exclusion_string not in current_line
"""

    def delete_reduction(self):
        current_row = self.reduction_table.currentRow()
        if current_row >= 0:
            self.reduction_table.removeRow(current_row)
            del self.main_window.current_project.reductions[current_row]
            self.main_window.is_project_modified = True

    def edit_reduction(self):
        current_row = self.reduction_table.currentRow()
        if current_row >= 0:
            reduction = self.main_window.current_project.reductions[current_row]
            dialog = ReductionDialog(self, reduction['name'], reduction['code'])
            if dialog.exec_() == QDialog.Accepted:
                # Update the reduction in the table and project
                self.reduction_table.setItem(current_row, 0, QTableWidgetItem(dialog.reduction_name))
                self.reduction_table.setItem(current_row, 1, QTableWidgetItem(dialog.reduction_code))

                self.main_window.current_project.reductions[current_row] = {
                    "name": dialog.reduction_name,
                    "code": dialog.reduction_code
                }
                self.main_window.is_project_modified = True

    def test_reduction(self):
        current_row = self.reduction_table.currentRow()
        if current_row >= 0:
            reduction = self.main_window.current_project.reductions[current_row]
            self.apply_reduction(reduction)

    def test_all_reductions(self):
        """Apply all reductions in sequence, chaining the results."""
        text_lines = self.main_window.current_project.text_content.splitlines()

        for reduction in self.main_window.current_project.reductions:
            text_lines = self.apply_reduction(reduction, text_lines)

        # Update the preview area with the final reduced text
        reduced_lines = [line for line in text_lines if line.strip()]
        self.preview_text_area.setText("\n".join(reduced_lines))

    def apply_reduction(self, reduction, text_lines=None):
        """Apply a single reduction to the provided text lines."""
        if text_lines is None:
            text_lines = self.main_window.current_project.text_content.splitlines()

        reduced_lines = []
        
        reduction_func = self.evaluate_code(reduction['code'])

        if not reduction_func:
            QMessageBox.critical(self, "Reduction Error",
                                 f"Reduction function {reduction['name']} could not be evaluated.")
            return text_lines

        for i in range(len(text_lines)):
            current_line = text_lines[i]
            prev_lines = text_lines[max(0, i - N):i]
            next_lines = text_lines[i + 1:min(len(text_lines), i + 1 + N)]
            if reduction_func(current_line, prev_lines, next_lines):
                reduced_lines.append(current_line)

        return reduced_lines

    def evaluate_code(self, code):
        """Evaluate the provided code as a function."""
        try:
            exec(code, globals())
            return eval('reduction_function')
        except Exception as e:
            QMessageBox.critical(self, "Code Error", f"Error in the code:\n{str(e)}")
            return None

class ReductionDialog(QDialog):
    _reduction_counter = 1  # Class variable to keep track of the number of reductions

    def __init__(self, parent=None, reduction_name="", reduction_code=""):
        super().__init__(parent)
        if reduction_name:
            self.reduction_name = reduction_name
        else:
            self.reduction_name = f"Reduction_{ReductionDialog._reduction_counter}"
            ReductionDialog._reduction_counter += 1

        self.reduction_code = reduction_code if reduction_code else self.get_default_template()
        self.initUI()

    def initUI(self):
        layout = QFormLayout()

        # LineEdit for reduction name
        self.reduction_name_edit = QLineEdit(self)
        self.reduction_name_edit.setText(self.reduction_name)
        layout.addRow("Reduction Name:", self.reduction_name_edit)

        # PyCodeEdit for Python code editing
        self.code_editor = PyCodeEdit(self)
        self.code_editor.backend.start(server.__file__)
        self.code_editor.setPlainText(self.reduction_code)

        layout.addRow("Reduction Code:", self.code_editor)

        # Dialog buttons
        self.button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        layout.addWidget(self.button_box)

        self.setLayout(layout)

    def get_default_template(self):
        return """def reduction_function(current_line, prev_lines, next_lines):
    # Edit this function to implement your reduction logic
    return True
"""

    def accept(self):
        self.reduction_name = self.reduction_name_edit.text()
        self.reduction_code = self.code_editor.toPlainText()
        super().accept()

    def reject(self):
        super().reject()

class TranslationBundleTab(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        # Create a splitter to hold the preview area and the table
        splitter = QSplitter(Qt.Horizontal)

        # Preview area
        self.preview_text_area = QTextEdit(self)
        self.preview_text_area.setReadOnly(True)
        splitter.addWidget(self.preview_text_area)

        # Table for storing translations
        self.translation_table = QTableWidget(0, 2, self)
        self.translation_table.setHorizontalHeaderLabels(["Original Word", "Replacement Word"])
        splitter.addWidget(self.translation_table)

        # Set the initial sizes for the splitter
        splitter.setStretchFactor(0, 7)  # 70% for the preview area
        splitter.setStretchFactor(1, 3)  # 30% for the table

        layout.addWidget(splitter)

        # Translation Toolbox
        toolbox_layout = QHBoxLayout()

        self.show_raw_button = QPushButton("Show RAW Text", self)
        self.show_raw_button.clicked.connect(self.show_raw_text)
        toolbox_layout.addWidget(self.show_raw_button)

        self.add_button = QPushButton("Add Translation", self)
        self.add_button.clicked.connect(self.add_translation)
        toolbox_layout.addWidget(self.add_button)

        self.delete_button = QPushButton("Delete Translation", self)
        self.delete_button.clicked.connect(self.delete_translation)
        toolbox_layout.addWidget(self.delete_button)

        self.test_button = QPushButton("Test Translation", self)
        self.test_button.clicked.connect(self.test_translation)
        toolbox_layout.addWidget(self.test_button)

        self.test_all_button = QPushButton("Test All", self)
        self.test_all_button.clicked.connect(self.test_all_translations)
        toolbox_layout.addWidget(self.test_all_button)

        layout.addLayout(toolbox_layout)
        self.setLayout(layout)

    def show_raw_text(self):
        """Display the raw text from the project in the preview area."""
        raw_text = self.main_window.current_project.text_content
        self.preview_text_area.setText(raw_text)

    def add_translation(self):
        selected_text = self.preview_text_area.textCursor().selectedText()
        dialog = TranslationDialog(self, selected_text)
        if dialog.exec_() == QDialog.Accepted:
            original_word = dialog.original_word
            replacement_word = dialog.replacement_word

            # Add translation to the table and project
            row_position = self.translation_table.rowCount()
            self.translation_table.insertRow(row_position)
            self.translation_table.setItem(row_position, 0, QTableWidgetItem(original_word))
            self.translation_table.setItem(row_position, 1, QTableWidgetItem(replacement_word))

            self.main_window.current_project.translations.append({
                "original_word": original_word,
                "replacement_word": replacement_word
            })
            self.main_window.is_project_modified = True

    def delete_translation(self):
        current_row = self.translation_table.currentRow()
        if current_row >= 0:
            self.translation_table.removeRow(current_row)
            del self.main_window.current_project.translations[current_row]
            self.main_window.is_project_modified = True

    def test_translation(self):
        current_row = self.translation_table.currentRow()
        if current_row >= 0:
            translation = self.main_window.current_project.translations[current_row]
            self.apply_translation(translation)

    def test_all_translations(self):
        for translation in self.main_window.current_project.translations:
            self.apply_translation(translation)

    def apply_translation(self, translation):
        text = self.main_window.current_project.text_content
        original_word = translation['original_word']
        replacement_word = translation['replacement_word']

        # Replace words in the text
        translated_text = text.replace(original_word, replacement_word)

        # Update the preview area with the translated text
        self.preview_text_area.setText(translated_text)

class TranslationDialog(QDialog):
    def __init__(self, parent=None, selected_text=""):
        super().__init__(parent)
        self.original_word = selected_text
        self.replacement_word = ""
        self.initUI()

    def initUI(self):
        layout = QFormLayout()

        # LineEdit for original word, pre-filled with selected text if available
        self.original_word_edit = QLineEdit(self)
        self.original_word_edit.setText(self.original_word)
        layout.addRow("Original Word:", self.original_word_edit)

        # LineEdit for replacement word
        self.replacement_word_edit = QLineEdit(self)
        layout.addRow("Replacement Word:", self.replacement_word_edit)

        # Dialog buttons
        self.button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        layout.addWidget(self.button_box)

        self.setLayout(layout)

    def accept(self):
        self.original_word = self.original_word_edit.text()
        self.replacement_word = self.replacement_word_edit.text()
        super().accept()

    def reject(self):
        super().reject()


class TextFileTab(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        # Read-only LineEdit to display filename
        self.filename_label = QLabel("Loaded File:")
        layout.addWidget(self.filename_label)
        self.filename_display = QLineEdit(self)
        self.filename_display.setReadOnly(True)
        layout.addWidget(self.filename_display)

        # Button to load a file
        self.load_button = QPushButton('Load Text File', self)
        self.load_button.clicked.connect(self.load_file)
        layout.addWidget(self.load_button)

        # Text area to display file content
        self.text_area = QTextEdit(self)
        layout.addWidget(self.text_area)

        self.setLayout(layout)

    def load_file(self):
        options = QFileDialog.Options()
        file_name, _ = QFileDialog.getOpenFileName(self, "Open Text File", "", "Text Files (*.txt);;All Files (*)",
                                                   options=options)
        if file_name:
            try:
                with open(file_name, 'r', encoding='utf-8') as file:
                    lines = file.readlines()
                    non_empty_lines = [line.replace('\n', '') for line in lines if line.strip()]
                    content = "\n".join(non_empty_lines)
                    self.text_area.setText(content)

                    # Update project information
                    self.main_window.current_project.loaded_filename = file_name
                    self.main_window.current_project.text_content = content
                    self.main_window.is_project_modified = True

                    # Update filename display
                    self.filename_display.setText(file_name)

                    self.main_window.statusBar().showMessage(f'Loaded file: {file_name}')
            except Exception as e:
                QMessageBox.critical(self, "Load Error", f"An error occurred while loading the file:\n{str(e)}")

    def save_state_to_project(self):
        """Save the current state of this tab to the project."""
        self.main_window.current_project.text_content = self.text_area.toPlainText()

    def load_content_from_project(self):
        """Load the content of the text area from the current project."""
        self.text_area.setText(self.main_window.current_project.text_content)
        if self.main_window.current_project.loaded_filename:
            self.filename_display.setText(self.main_window.current_project.loaded_filename)


class ParsingTab(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window
        self.cluster_parsers = {}
        self.initUI()

    def initUI(self):
        main_layout = QVBoxLayout()

        # Load Clusters and Text Button
        load_button_layout = QHBoxLayout()
        self.load_button = QPushButton("Load Clusters and Text", self)
        self.load_button.clicked.connect(self.load_clusters_and_text)
        load_button_layout.addWidget(self.load_button)
        main_layout.addLayout(load_button_layout)

        # Create a horizontal layout for the tree and editor
        tree_editor_layout = QHBoxLayout()

        # QTreeWidget for displaying clusters with additional columns
        self.cluster_tree = QTreeWidget(self)
        self.cluster_tree.setHeaderLabels(["Cluster", "Enabled", "Root", "Nesting", "Group Cardinality", "Sibling Relationship"])
        self.cluster_tree.setColumnWidth(0, 200)  # Set width for the "Cluster" column
        self.cluster_tree.setDragDropMode(QAbstractItemView.InternalMove)  # Enable drag and drop for reordering
        self.cluster_tree.itemClicked.connect(self.on_cluster_selected)
        tree_editor_layout.addWidget(self.cluster_tree)

        # PyQod editor for editing parser functions
        self.code_editor = PyCodeEdit(self)
        self.code_editor.backend.start(server.__file__)
        tree_editor_layout.addWidget(self.code_editor)

        main_layout.addLayout(tree_editor_layout)

        # Two Preview Text Areas
        preview_layout = QHBoxLayout()

        self.preprocessed_text_area = QTextEdit(self)
        self.preprocessed_text_area.setReadOnly(True)
        preview_layout.addWidget(self.preprocessed_text_area)

        self.parsed_text_area = QTextEdit(self)
        self.parsed_text_area.setReadOnly(True)
        preview_layout.addWidget(self.parsed_text_area)

        main_layout.addLayout(preview_layout)

        # Button Layout
        button_layout = QHBoxLayout()

        self.save_button = QPushButton("Save Parser", self)
        self.save_button.clicked.connect(self.save_parser)
        self.save_button.setEnabled(False)
        button_layout.addWidget(self.save_button)

        self.test_button = QPushButton("Test Parser", self)
        self.test_button.clicked.connect(self.test_parser)
        self.test_button.setEnabled(False)
        button_layout.addWidget(self.test_button)

        self.clear_button = QPushButton("Clear Parser", self)
        self.clear_button.clicked.connect(self.clear_parser)
        self.clear_button.setEnabled(False)
        button_layout.addWidget(self.clear_button)

        self.run_all_button = QPushButton("Run All Parsers", self)
        self.run_all_button.clicked.connect(self.run_all_parsers)
        button_layout.addWidget(self.run_all_button)

        main_layout.addLayout(button_layout)

        self.setLayout(main_layout)

    def save_state_to_project(self):
        """Save the current state of the parsing tab to the project."""
        self.main_window.current_project.cluster_parsers = self.cluster_parsers
        self.main_window.current_project.cluster_tree_structure = self.get_tree_structure()

    def load_content_from_project(self):
        """Load the saved state of the parsing tab from the project."""
        self.cluster_parsers = self.main_window.current_project.cluster_parsers
        self.load_tree_structure(self.main_window.current_project.cluster_tree_structure)

    def get_tree_structure(self):
        """Recursively retrieve the tree structure."""
        def recurse_tree(item):
            children = []
            for i in range(item.childCount()):
                child = item.child(i)
                children.append(recurse_tree(child))
            return {
                "label": item.text(0),
                "enabled": item.checkState(1) == Qt.Checked,
                "root": item.checkState(2) == Qt.Checked,
                "nesting": self.cluster_tree.itemWidget(item, 3).currentText(),
                "group_cardinality": self.cluster_tree.itemWidget(item, 4).currentText(),
                "sibling_relationship": self.cluster_tree.itemWidget(item, 5).currentText(),
                "children": children
            }

        tree_structure = []
        for i in range(self.cluster_tree.topLevelItemCount()):
            item = self.cluster_tree.topLevelItem(i)
            tree_structure.append(recurse_tree(item))
        return tree_structure

    def load_tree_structure(self, structure, parent_item=None):
        """Recursively load the tree structure."""
        def recurse_load(item_structure, parent_item):
            item = QTreeWidgetItem(parent_item, [item_structure["label"]])
            item.setCheckState(1, Qt.Checked if item_structure["enabled"] else Qt.Unchecked)
            item.setCheckState(2, Qt.Checked if item_structure["root"] else Qt.Unchecked)

            # Nesting ComboBox
            nesting_combo = QComboBox()
            nesting_combo.addItems(["No Children (0:0)", "Single Child (1:1)", "Multiple Children (1:N)", "Optional Multiple Children (0:N)"])
            nesting_combo.setCurrentText(item_structure["nesting"])
            self.cluster_tree.setItemWidget(item, 3, nesting_combo)

            # Group Cardinality ComboBox
            group_cardinality_combo = QComboBox()
            group_cardinality_combo.addItems(["Single (1)", "Multiple (N)", "Optional (0:1)"])
            group_cardinality_combo.setCurrentText(item_structure["group_cardinality"])
            self.cluster_tree.setItemWidget(item, 4, group_cardinality_combo)

            # Sibling Relationship ComboBox
            sibling_relationship_combo = QComboBox()
            sibling_relationship_combo.addItems(["Ordered (Seq)", "Unordered (Unord)", "Repeatable (Rep)"])
            sibling_relationship_combo.setCurrentText(item_structure["sibling_relationship"])
            self.cluster_tree.setItemWidget(item, 5, sibling_relationship_combo)

            if parent_item is None:
                self.cluster_tree.addTopLevelItem(item)
            for child in item_structure["children"]:
                recurse_load(child, item)

        self.cluster_tree.clear()
        for item_structure in structure:
            recurse_load(item_structure, parent_item=None)

    def load_clusters_and_text(self):
        """Load clusters and preprocessed text from the ClusteringTab."""
        clustering_tab = self.main_window.clustering_tab

        # Load clusters into the tree
        clusters = clustering_tab.cluster_parser.tagged_lines['Cluster'].unique()
        self.load_clusters(clusters)

        # Load preprocessed text
        preprocessed_text = self.get_preprocessed_text()
        self.preprocessed_text_area.setPlainText("\n".join(preprocessed_text))

    def load_clusters(self, clusters):
        """Load clusters into the tree."""
        self.cluster_tree.clear()
        for cluster in clusters:
            item = QTreeWidgetItem(self.cluster_tree, [f"Cluster {cluster}"])
            item.setCheckState(1, Qt.Unchecked)  # Default "Enabled" to false
            item.setCheckState(2, Qt.Unchecked)  # Default "Root" to false

            # Nesting ComboBox
            nesting_combo = QComboBox()
            nesting_combo.addItems(["No Children (0:0)", "Single Child (1:1)", "Multiple Children (1:N)", "Optional Multiple Children (0:N)"])
            nesting_combo.setCurrentText("No Children (0:0)")  # Default to "No Children"
            self.cluster_tree.setItemWidget(item, 3, nesting_combo)

            # Group Cardinality ComboBox
            group_cardinality_combo = QComboBox()
            group_cardinality_combo.addItems(["Single (1)", "Multiple (N)", "Optional (0:1)"])
            group_cardinality_combo.setCurrentText("Single (1)")
            self.cluster_tree.setItemWidget(item, 4, group_cardinality_combo)

            # Sibling Relationship ComboBox
            sibling_relationship_combo = QComboBox()
            sibling_relationship_combo.addItems(["Ordered (Seq)", "Unordered (Unord)", "Repeatable (Rep)"])
            sibling_relationship_combo.setCurrentText("Ordered (Seq)")
            self.cluster_tree.setItemWidget(item, 5, sibling_relationship_combo)

            self.cluster_tree.addTopLevelItem(item)
            if cluster not in self.cluster_parsers:
                self.cluster_parsers[cluster] = self.default_parser_function()

    def default_parser_function(self):
        """Returns the default parser function code."""
        return """
def parser_function(line):
    return {}
"""

    def on_cluster_selected(self, item, column):
        """Load the parser function for the selected cluster."""
        cluster_label = item.text(0)
        cluster_id = int(cluster_label.split(" ")[1])
        self.code_editor.setPlainText(self.cluster_parsers[cluster_id])
        self.save_button.setEnabled(True)
        self.test_button.setEnabled(True)
        self.clear_button.setEnabled(True)

    def save_parser(self):
        """Save the current code from the editor as the parser function for the selected cluster."""
        selected_item = self.cluster_tree.currentItem()
        if selected_item:
            cluster_label = selected_item.text(0)
            cluster_id = int(cluster_label.split(" ")[1])
            self.cluster_parsers[cluster_id] = self.code_editor.toPlainText()

    def test_parser(self):
        """Test the parser function on lines of the selected cluster."""
        selected_item = self.cluster_tree.currentItem()
        if selected_item:
            cluster_label = selected_item.text(0)
            cluster_id = int(cluster_label.split(" ")[1])
            parser_code = self.cluster_parsers[cluster_id]
            parser_func = self.evaluate_code(parser_code)

            if parser_func:
                preprocessed_text = self.preprocessed_text_area.toPlainText().splitlines()
                tagged_lines = self.main_window.clustering_tab.cluster_parser.tagged_lines
                cluster_lines = tagged_lines[tagged_lines['Cluster'] == cluster_id]['Line']
                parsed_results = [parser_func(line) for line in cluster_lines]
                self.parsed_text_area.setPlainText("\n".join(str(result) for result in parsed_results))

    def clear_parser(self):
        """Reset the parser function to the default for the selected cluster."""
        selected_item = self.cluster_tree.currentItem()
        if selected_item:
            cluster_label = selected_item.text(0)
            cluster_id = int(cluster_label.split(" ")[1])
            self.cluster_parsers[cluster_id] = self.default_parser_function()
            self.code_editor.setPlainText(self.cluster_parsers[cluster_id])

    def run_all_parsers(self):
        """Run all parser functions on their respective clusters and display the results."""
        tagged_lines = self.main_window.clustering_tab.cluster_parser.tagged_lines
        parsed_results = []

        for _, row in tagged_lines.iterrows():
            cluster_id = row['Cluster']
            line = row['Line']

            if cluster_id in self.cluster_parsers:
                parser_code = self.cluster_parsers[cluster_id]
                parser_func = self.evaluate_code(parser_code)

                if parser_func:
                    parsed_result = parser_func(line)
                    parsed_results.append(parsed_result)

        self.parsed_text_area.setPlainText("\n".join(str(result) for result in parsed_results))

    def evaluate_code(self, code):
        """Evaluate the provided code as a function."""
        try:
            exec(code, globals())
            return eval('parser_function')
        except Exception as e:
            QMessageBox.critical(self, "Code Error", f"Error in the code:\n{str(e)}")
            return None

    def get_preprocessed_text(self):
        """Get the preprocessed text."""
        return self.main_window.preprocessing_tab.execute_operations()

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.current_project = ParserProject()
        self.is_project_modified = False
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Parser Project Manager')

        # Menu bar
        menubar = self.menuBar()
        file_menu = menubar.addMenu('File')

        # New Project action
        new_project_action = QAction('New Project', self)
        new_project_action.triggered.connect(self.new_project)
        file_menu.addAction(new_project_action)

        # Save Project action
        save_project_action = QAction('Save Project', self)
        save_project_action.triggered.connect(self.save_project)
        file_menu.addAction(save_project_action)

        # Load Project action
        load_project_action = QAction('Load Project', self)
        load_project_action.triggered.connect(self.load_project)
        file_menu.addAction(load_project_action)

        # Exit action
        exit_action = QAction('Exit', self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        # Tabs
        self.tab_widget = QTabWidget()
        self.setCentralWidget(self.tab_widget)

        # Add the tabs
        self.add_tabs()

        self.setGeometry(100, 100, 800, 600)

    def add_tabs(self):
        self.text_file_tab = TextFileTab(self)
        self.tab_widget.addTab(self.text_file_tab, "Text File")

        self.transformation_tab = TransformationTab(self)
        self.tab_widget.addTab(self.transformation_tab, "Transformation")

        self.translation_bundle_tab = TranslationBundleTab(self)
        self.tab_widget.addTab(self.translation_bundle_tab, "Translation Bundle")

        self.reduction_tab = ReductionTab(self)
        self.tab_widget.addTab(self.reduction_tab, "Reduction")

        self.preprocessing_tab = PreprocessingTab(self)
        self.tab_widget.addTab(self.preprocessing_tab, "Preprocessing")

        self.clustering_tab = ClusteringTab(self)
        self.tab_widget.addTab(self.clustering_tab, "Clustering")

        self.parsing_tab = ParsingTab(self)
        self.tab_widget.addTab(self.parsing_tab, "Parsing")

    def new_project(self):
        if self.is_project_modified:
            reply = QMessageBox.question(
                self, 'Save Project',
                "Do you want to save the current project before creating a new one?",
                QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel, QMessageBox.Cancel
            )
            if reply == QMessageBox.Yes:
                if not self.save_project():
                    return
            elif reply == QMessageBox.Cancel:
                return

        self.current_project = ParserProject()
        self.is_project_modified = False
        self.text_file_tab.load_content_from_project()
        self.transformation_tab.transformation_table.setRowCount(0)
        self.translation_bundle_tab.translation_table.setRowCount(0)
        self.reduction_tab.reduction_table.setRowCount(0)
        self.preprocessing_tab.load_content_from_project()  # Reset preprocessing order
        self.clustering_tab.load_content_from_project()  # Load clustering content
        self.statusBar().showMessage('New project created.')

    def save_project(self):
        try:
            # Call save_state_to_project for each tab
            self.text_file_tab.save_state_to_project()
            self.clustering_tab.save_state_to_project()

            options = QFileDialog.Options()
            file_name, _ = QFileDialog.getSaveFileName(self, "Save Project", "", "JSON Files (*.json);;All Files (*)",
                                                       options=options)
            if file_name:
                try:
                    with open(file_name, 'w') as file:
                        json.dump(self.current_project.to_dict(), file, indent=4)
                    self.is_project_modified = False
                    self.statusBar().showMessage(f'Project saved to {file_name}')
                    return True
                except Exception as e:
                    QMessageBox.critical(self, "Save Error", f"An error occurred while saving the project:\n{str(e)}")
                    return False
        except Exception as e:
            print(e)
        return False

    def load_project(self):
        options = QFileDialog.Options()
        file_name, _ = QFileDialog.getOpenFileName(self, "Open Project", "", "JSON Files (*.json);;All Files (*)",
                                                   options=options)
        if file_name:
            try:
                with open(file_name, 'r') as file:
                    data = json.load(file)
                    self.current_project.from_dict(data)
                    self.is_project_modified = False

                    # Load content for each tab
                    self.text_file_tab.load_content_from_project()
                    self.clustering_tab.load_content_from_project()
                    self.load_transformations_to_table()
                    self.load_translations_to_table()
                    self.load_reductions_to_table()
                    self.preprocessing_tab.load_content_from_project()  # Load preprocessing order

                    self.statusBar().showMessage(f'Project loaded from {file_name}')
            except Exception as e:
                QMessageBox.critical(self, "Load Error", f"An error occurred while loading the project:\n{str(e)}")

    def load_transformations_to_table(self):
        self.transformation_tab.transformation_table.setRowCount(0)
        for transformation in self.current_project.transformations:
            row_position = self.transformation_tab.transformation_table.rowCount()
            self.transformation_tab.transformation_table.insertRow(row_position)
            self.transformation_tab.transformation_table.setItem(row_position, 0,
                                                                 QTableWidgetItem(transformation['name']))
            self.transformation_tab.transformation_table.setItem(row_position, 1,
                                                                 QTableWidgetItem(transformation['code']))

    def load_translations_to_table(self):
        self.translation_bundle_tab.translation_table.setRowCount(0)
        for translation in self.current_project.translations:
            row_position = self.translation_bundle_tab.translation_table.rowCount()
            self.translation_bundle_tab.translation_table.insertRow(row_position)
            self.translation_bundle_tab.translation_table.setItem(row_position, 0,
                                                                  QTableWidgetItem(translation['original_word']))
            self.translation_bundle_tab.translation_table.setItem(row_position, 1,
                                                                  QTableWidgetItem(translation['replacement_word']))

    def load_reductions_to_table(self):
        self.reduction_tab.reduction_table.setRowCount(0)
        for reduction in self.current_project.reductions:
            row_position = self.reduction_tab.reduction_table.rowCount()
            self.reduction_tab.reduction_table.insertRow(row_position)
            self.reduction_tab.reduction_table.setItem(row_position, 0, QTableWidgetItem(reduction['name']))
            self.reduction_tab.reduction_table.setItem(row_position, 1, QTableWidgetItem(reduction['code']))

    def closeEvent(self, event):
        if self.is_project_modified:
            reply = QMessageBox.question(
                self, 'Save Project',
                "Do you want to save the current project before exiting?",
                QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel, QMessageBox.Cancel
            )
            if reply == QMessageBox.Yes:
                if not self.save_project():
                    event.ignore()
                    return
            elif reply == QMessageBox.Cancel:
                event.ignore()
                return

        event.accept()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    main_win = MainWindow()
    main_win.show()
    sys.exit(app.exec_())
