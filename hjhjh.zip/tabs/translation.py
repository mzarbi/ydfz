from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QSplitter, QTextEdit, QTableWidget, QHBoxLayout, QPushButton, QDialog, \
    QTableWidgetItem, QFormLayout, QLineEdit, QDialogButtonBox, QHeaderView


class TranslationBundleTab(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        # Create a splitter to hold the preview area and the table
        splitter = QSplitter(Qt.Horizontal)

        # Preview area
        self.preview_text_area = QTextEdit(self)
        self.preview_text_area.setReadOnly(True)
        splitter.addWidget(self.preview_text_area)

        # Table for storing translations
        self.translation_table = QTableWidget(0, 2, self)
        self.translation_table.setHorizontalHeaderLabels(["Original Word", "Replacement Word"])

        header = self.translation_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Stretch)

        # Connect the cellChanged signal to update_translation slot
        self.translation_table.cellChanged.connect(self.update_translation)

        splitter.addWidget(self.translation_table)

        # Set the initial sizes for the splitter
        splitter.setStretchFactor(0, 7)  # 70% for the preview area
        splitter.setStretchFactor(1, 3)  # 30% for the table

        layout.addWidget(splitter)

        # Translation Toolbox
        toolbox_layout = QHBoxLayout()

        self.show_raw_button = QPushButton("Show Baseline", self)
        self.show_raw_button.clicked.connect(self.show_baseline)
        toolbox_layout.addWidget(self.show_raw_button)

        self.set_baseline_button = QPushButton("Set Baseline", self)
        self.set_baseline_button.clicked.connect(self.set_baseline)
        toolbox_layout.addWidget(self.set_baseline_button)

        self.add_button = QPushButton("Add Translation", self)
        self.add_button.clicked.connect(self.add_translation)
        toolbox_layout.addWidget(self.add_button)

        self.delete_button = QPushButton("Delete Translation", self)
        self.delete_button.clicked.connect(self.delete_translation)
        toolbox_layout.addWidget(self.delete_button)

        self.test_button = QPushButton("Test Translation", self)
        self.test_button.clicked.connect(self.test_translation)
        toolbox_layout.addWidget(self.test_button)

        self.test_all_button = QPushButton("Test All", self)
        self.test_all_button.clicked.connect(self.test_all_translations)
        toolbox_layout.addWidget(self.test_all_button)

        layout.addLayout(toolbox_layout)
        self.setLayout(layout)

    def set_baseline(self):
        self.main_window.current_project.baseline = self.preview_text_area.toPlainText()
        self.main_window.statusBar().showMessage(f'Baseline changed to the translated data')

    def show_baseline(self):
        """Display the raw text from the project in the preview area."""
        raw_text = self.main_window.current_project.baseline
        self.preview_text_area.setText(raw_text)

    def add_translation(self):
        selected_text = self.preview_text_area.textCursor().selectedText()
        dialog = TranslationDialog(self, selected_text)
        if dialog.exec_() == QDialog.Accepted:
            original_word = dialog.original_word
            replacement_word = dialog.replacement_word

            # Temporarily block the cellChanged signal
            self.translation_table.blockSignals(True)

            # Add translation to the table and project
            row_position = self.translation_table.rowCount()
            self.translation_table.insertRow(row_position)
            self.translation_table.setItem(row_position, 0, QTableWidgetItem(original_word))
            self.translation_table.setItem(row_position, 1, QTableWidgetItem(replacement_word))

            self.main_window.current_project.translations.append({
                "original_word": original_word,
                "replacement_word": replacement_word
            })
            self.main_window.is_project_modified = True

            # Unblock the cellChanged signal
            self.translation_table.blockSignals(False)

    def delete_translation(self):
        current_row = self.translation_table.currentRow()
        if current_row >= 0:
            # Temporarily block the cellChanged signal
            self.translation_table.blockSignals(True)

            # Remove the row from the table and the corresponding entry from translations
            self.translation_table.removeRow(current_row)
            del self.main_window.current_project.translations[current_row]
            self.main_window.is_project_modified = True

            # Unblock the cellChanged signal
            self.translation_table.blockSignals(False)

    def update_translation(self, row, column):
        # Get the new value from the table
        new_value = self.translation_table.item(row, column).text()

        # Update the corresponding translation in the translations list
        if column == 0:  # First column corresponds to the original word
            self.main_window.current_project.translations[row]['original_word'] = new_value
        elif column == 1:  # Second column corresponds to the replacement word
            self.main_window.current_project.translations[row]['replacement_word'] = new_value

        # Mark the project as modified
        self.main_window.is_project_modified = True

    def test_translation(self):
        current_row = self.translation_table.currentRow()
        if current_row >= 0:
            translation = self.main_window.current_project.translations[current_row]
            self.apply_translation(translation)

    def test_all_translations(self):
        for translation in self.main_window.current_project.translations:
            self.apply_translation(translation)

    def apply_translation(self, translation):
        text = self.main_window.current_project.baseline
        original_word = translation['original_word']
        replacement_word = translation['replacement_word']

        # Replace words in the text
        translated_text = text.replace(original_word, replacement_word)

        # Update the preview area with the translated text
        self.preview_text_area.setText(translated_text)

class TranslationDialog(QDialog):
    def __init__(self, parent=None, selected_text=""):
        super().__init__(parent)
        self.original_word = selected_text
        self.replacement_word = ""
        self.initUI()

    def initUI(self):
        layout = QFormLayout()

        # LineEdit for original word, pre-filled with selected text if available
        self.original_word_edit = QLineEdit(self)
        self.original_word_edit.setText(self.original_word)
        layout.addRow("Original Word:", self.original_word_edit)

        # LineEdit for replacement word
        self.replacement_word_edit = QLineEdit(self)
        layout.addRow("Replacement Word:", self.replacement_word_edit)

        # Dialog buttons
        self.button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        layout.addWidget(self.button_box)

        self.setLayout(layout)
        self.resize(800, 300)

    def accept(self):
        self.original_word = self.original_word_edit.text()
        self.replacement_word = self.replacement_word_edit.text()
        super().accept()

    def reject(self):
        super().reject()

