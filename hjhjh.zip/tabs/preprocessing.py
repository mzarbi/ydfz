import re

from PyQt5.QtWidgets import QWidget, QVBoxLayout, QTextEdit, QTableWidget, QHBoxLayout, QPushButton, QDialog, \
    QTableWidgetItem, QMessageBox, QComboBox, QListWidget, QDialogButtonBox, QHeaderView

from tabs.utils import N


class PreprocessingTab(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        ext_area_layout = QHBoxLayout()
        # Preview area
        self.preview_text_area = QTextEdit(self)
        self.preview_text_area.setReadOnly(True)
        ext_area_layout.addWidget(self.preview_text_area, stretch=7)

        # Table for specifying the order of operations
        self.order_table = QTableWidget(0, 2, self)
        self.order_table.setHorizontalHeaderLabels(["Operation Type", "Name"])

        header = self.order_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Stretch)

        ext_area_layout.addWidget(self.order_table, stretch=3)
        layout.addLayout(ext_area_layout)

        # Toolbox for managing the order
        toolbox_layout = QHBoxLayout()

        self.show_raw_button = QPushButton("Show Baseline", self)
        self.show_raw_button.clicked.connect(self.show_baseline)
        toolbox_layout.addWidget(self.show_raw_button)

        self.set_baseline_button = QPushButton("Set Baseline", self)
        self.set_baseline_button.clicked.connect(self.set_baseline)
        toolbox_layout.addWidget(self.set_baseline_button)

        self.add_button = QPushButton("Add Operation", self)
        self.add_button.clicked.connect(self.add_operation)
        toolbox_layout.addWidget(self.add_button)

        self.add_all_button = QPushButton("Add All", self)
        self.add_all_button.clicked.connect(self.add_all_operations)
        toolbox_layout.addWidget(self.add_all_button)

        self.remove_button = QPushButton("Remove Operation", self)
        self.remove_button.clicked.connect(self.remove_operation)
        toolbox_layout.addWidget(self.remove_button)

        self.move_up_button = QPushButton("Move Up", self)
        self.move_up_button.clicked.connect(self.move_operation_up)
        toolbox_layout.addWidget(self.move_up_button)

        self.move_down_button = QPushButton("Move Down", self)
        self.move_down_button.clicked.connect(self.move_operation_down)
        toolbox_layout.addWidget(self.move_down_button)

        self.execute_button = QPushButton("Execute", self)
        self.execute_button.clicked.connect(self.execute_operations)
        toolbox_layout.addWidget(self.execute_button)

        layout.addLayout(toolbox_layout)
        self.setLayout(layout)

    def set_baseline(self):
        self.main_window.current_project.baseline = self.preview_text_area.toPlainText()
        self.main_window.statusBar().showMessage(f'Baseline changed to the preprocessing data')

    def show_baseline(self):
        """Display the raw text from the project in the preview area."""
        raw_text = self.main_window.current_project.text_content
        self.preview_text_area.setText(raw_text)

    def add_operation(self):
        dialog = AddOperationDialog(self.main_window)
        if dialog.exec_() == QDialog.Accepted:
            operation_type, name = dialog.get_selected_operation()

            # Add the selected operation to the table
            row_position = self.order_table.rowCount()
            self.order_table.insertRow(row_position)
            self.order_table.setItem(row_position, 0, QTableWidgetItem(operation_type))
            self.order_table.setItem(row_position, 1, QTableWidgetItem(name))

            self.main_window.current_project.preprocessing_order.append({
                "type": operation_type,
                "name": name
            })
            self.main_window.is_project_modified = True

    def add_all_operations(self):
        for operation in self.main_window.current_project.transformations:
            name = operation['name']
            operation_type = "Transformation"

            # Add the operation to the table
            row_position = self.order_table.rowCount()
            self.order_table.insertRow(row_position)
            self.order_table.setItem(row_position, 0, QTableWidgetItem(operation_type))
            self.order_table.setItem(row_position, 1, QTableWidgetItem(name))

            self.main_window.current_project.preprocessing_order.append({
                "type": operation_type,
                "name": name
            })

        for operation in self.main_window.current_project.reductions:
            name = operation['name']
            operation_type = "Reduction"

            # Add the operation to the table
            row_position = self.order_table.rowCount()
            self.order_table.insertRow(row_position)
            self.order_table.setItem(row_position, 0, QTableWidgetItem(operation_type))
            self.order_table.setItem(row_position, 1, QTableWidgetItem(name))

            self.main_window.current_project.preprocessing_order.append({
                "type": operation_type,
                "name": name
            })

        for operation in self.main_window.current_project.translations:
            name = operation['original_word']
            operation_type = "Translation"

            # Add the operation to the table
            row_position = self.order_table.rowCount()
            self.order_table.insertRow(row_position)
            self.order_table.setItem(row_position, 0, QTableWidgetItem(operation_type))
            self.order_table.setItem(row_position, 1, QTableWidgetItem(name))

            self.main_window.current_project.preprocessing_order.append({
                "type": operation_type,
                "name": name
            })

        self.main_window.is_project_modified = True

    def remove_operation(self):
        current_row = self.order_table.currentRow()
        if current_row >= 0:
            self.order_table.removeRow(current_row)
            del self.main_window.current_project.preprocessing_order[current_row]
            self.main_window.is_project_modified = True

    def move_operation_up(self):
        current_row = self.order_table.currentRow()
        if current_row > 0:
            self.order_table.insertRow(current_row - 1)
            for col in range(self.order_table.columnCount()):
                self.order_table.setItem(current_row - 1, col, self.order_table.takeItem(current_row + 1, col))
            self.order_table.removeRow(current_row + 1)
            self.order_table.setCurrentCell(current_row - 1, 0)

            # Move operation in preprocessing_order
            self.main_window.current_project.preprocessing_order.insert(current_row - 1,
                                                                        self.main_window.current_project.preprocessing_order.pop(
                                                                            current_row))
            self.main_window.is_project_modified = True

    def move_operation_down(self):
        current_row = self.order_table.currentRow()
        if current_row < self.order_table.rowCount() - 1:
            self.order_table.insertRow(current_row + 2)
            for col in range(self.order_table.columnCount()):
                self.order_table.setItem(current_row + 2, col, self.order_table.takeItem(current_row, col))
            self.order_table.removeRow(current_row)
            self.order_table.setCurrentCell(current_row + 1, 0)

            # Move operation in preprocessing_order
            self.main_window.current_project.preprocessing_order.insert(current_row + 1,
                                                                        self.main_window.current_project.preprocessing_order.pop(
                                                                            current_row))
            self.main_window.is_project_modified = True

    def execute_operations(self):
        text_lines = self.main_window.current_project.text_content.splitlines()

        for operation in self.main_window.current_project.preprocessing_order:
            operation_type = operation["type"]
            name = operation["name"]

            if operation_type == "Transformation":
                op = next((t for t in self.main_window.current_project.transformations if t['name'] == name), None)
                if op:
                    text_lines = self.apply_transformation(op, text_lines)
            elif operation_type == "Reduction":
                op = next((r for r in self.main_window.current_project.reductions if r['name'] == name), None)
                if op:
                    text_lines = self.apply_reduction(op, text_lines)
            elif operation_type == "Translation":
                op = next((tr for tr in self.main_window.current_project.translations if tr['original_word'] == name),
                          None)
                if op:
                    text_lines = self.apply_translation(op, text_lines)

        # Display the final output in the preview area
        self.preview_text_area.setText("\n".join(text_lines))
        return text_lines

    def apply_transformation(self, transformation, text_lines):
        transformed_lines = []
        transformation_func = self.evaluate_code(transformation['code'])

        if not transformation_func:
            QMessageBox.critical(self, "Transformation Error",
                                 f"Transformation function {transformation['name']} could not be evaluated.")
            return text_lines

        for i in range(len(text_lines)):
            current_line = text_lines[i]
            prev_lines = text_lines[max(0, i - N):i]
            next_lines = text_lines[i + 1:min(len(text_lines), i + 1 + N)]
            transformed_line = transformation_func(current_line, prev_lines, next_lines)
            transformed_lines.append(transformed_line)

        return transformed_lines

    def apply_reduction(self, reduction, text_lines):
        reduced_lines = []
        reduction_func = self.evaluate_code(reduction['code'])

        if not reduction_func:
            QMessageBox.critical(self, "Reduction Error",
                                 f"Reduction function {reduction['name']} could not be evaluated.")
            return text_lines

        for i in range(len(text_lines)):
            current_line = text_lines[i]
            prev_lines = text_lines[max(0, i - N):i]
            next_lines = text_lines[i + 1:min(len(text_lines), i + 1 + N)]
            if reduction_func(current_line, prev_lines, next_lines):
                reduced_lines.append(current_line)

        return reduced_lines

    def apply_translation(self, translation, text_lines):
        return [line.replace(translation['original_word'], translation['replacement_word']) for line in text_lines]

    def get_function_name(self, python_string):
        match = re.search(r'def\s+(\w+)\s*\(', python_string)
        if match:
            return match.group(1)
        return None

    def evaluate_code(self, code):
        """Evaluate the provided code as a function."""
        try:
            exec(code, globals())
            return eval(self.get_function_name(code))
        except Exception as e:
            QMessageBox.critical(self, "Code Error", f"Error in the code:\n{str(e)}")
            return None

    def load_content_from_project(self):
        """Load the content of the order table from the current project."""
        self.order_table.setRowCount(0)
        for operation in self.main_window.current_project.preprocessing_order:
            row_position = self.order_table.rowCount()
            self.order_table.insertRow(row_position)
            self.order_table.setItem(row_position, 0, QTableWidgetItem(operation["type"]))
            self.order_table.setItem(row_position, 1, QTableWidgetItem(operation["name"]))



class AddOperationDialog(QDialog):
    def __init__(self, main_window):
        super().__init__(main_window)
        self.main_window = main_window
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        self.operation_type_combo = QComboBox(self)
        self.operation_type_combo.addItems(["Transformation", "Reduction", "Translation"])
        self.operation_type_combo.currentIndexChanged.connect(self.update_operation_list)
        layout.addWidget(self.operation_type_combo)

        self.operation_list = QListWidget(self)
        layout.addWidget(self.operation_list)

        self.update_operation_list()

        self.button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        layout.addWidget(self.button_box)

        self.setLayout(layout)

    def update_operation_list(self):
        self.operation_list.clear()
        operation_type = self.operation_type_combo.currentText()

        if operation_type == "Transformation":
            for transformation in self.main_window.current_project.transformations:
                self.operation_list.addItem(transformation['name'])
        elif operation_type == "Reduction":
            for reduction in self.main_window.current_project.reductions:
                self.operation_list.addItem(reduction['name'])
        elif operation_type == "Translation":
            for translation in self.main_window.current_project.translations:
                self.operation_list.addItem(translation['original_word'])

    def get_selected_operation(self):
        operation_type = self.operation_type_combo.currentText()
        name = self.operation_list.currentItem().text()
        return operation_type, name

    def accept(self):
        super().accept()

    def reject(self):
        super().reject()

