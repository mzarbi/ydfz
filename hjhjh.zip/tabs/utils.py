from PyQt5.QtWidgets import QMessageBox

N = 2  # Number of previous and next lines to consider
def try_(show_message=True):
    def decorator(func):
        def wrapper(self, *args, **kwargs):
            try:
                return func(self, *args, **kwargs)
            except Exception as e:
                # Log the error
                print(f"Exception occurred in {func.__name__}: {e}", exc_info=True)

        return wrapper

    return decorator