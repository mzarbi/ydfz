import inspect

from PyQt5.QtWidgets import QWidget, QVBoxLayout, QTextEdit, QTableWidget, QHBoxLayout, QPushButton, QDialog, \
    QTableWidgetItem, QMessageBox, QFormLayout, QComboBox, QDialogButtonBox
from pyqode.python.widgets import PyCodeEdit
from pyqode.python.backend import server
# Constants



# Example transformations (as placeholders)
from tabs.utils import N


def uppercase_transformation(current_line, prev_lines, next_lines):
    return current_line.upper()


def reverse_transformation(current_line, prev_lines, next_lines):
    return current_line[::-1]


def transformation(current_line, prev_lines, next_lines):
    return current_line


def strip_transformation(current_line, prev_lines, next_lines):
    return current_line.strip()


TRANSFORMATIONS = {
    "Transformation": transformation,
    "Uppercase": uppercase_transformation,
    "Reverse": reverse_transformation,
    "Strip": strip_transformation
}


class TransformationTab(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        ext_area_layout = QHBoxLayout()

        # Preview area
        self.preview_text_area = QTextEdit(self)
        self.preview_text_area.setReadOnly(True)
        ext_area_layout.addWidget(self.preview_text_area, stretch=7)

        # Table for storing transformations
        self.transformation_table = QTableWidget(0, 2, self)
        self.transformation_table.setHorizontalHeaderLabels(["Transformation", "Details"])
        header = self.transformation_table.horizontalHeader()
        header.setStretchLastSection(True)

        # Connect the cellChanged signal to update_transformation slot
        self.transformation_table.cellChanged.connect(self.update_transformation)

        ext_area_layout.addWidget(self.transformation_table, stretch=3)

        layout.addLayout(ext_area_layout)
        # Transformation Toolbox
        toolbox_layout = QHBoxLayout()

        self.show_baseline_button = QPushButton("Show Baseline", self)
        self.show_baseline_button.clicked.connect(self.show_baseline)
        toolbox_layout.addWidget(self.show_baseline_button)

        self.set_baseline_button = QPushButton("Set Baseline", self)
        self.set_baseline_button.clicked.connect(self.set_baseline)
        toolbox_layout.addWidget(self.set_baseline_button)

        self.add_button = QPushButton("Add Transformation", self)
        self.add_button.clicked.connect(self.add_transformation)
        toolbox_layout.addWidget(self.add_button)

        self.edit_button = QPushButton("Edit Transformation", self)
        self.edit_button.clicked.connect(self.edit_transformation)
        toolbox_layout.addWidget(self.edit_button)

        self.delete_button = QPushButton("Delete Transformation", self)
        self.delete_button.clicked.connect(self.delete_transformation)
        toolbox_layout.addWidget(self.delete_button)

        self.test_button = QPushButton("Test Transformation", self)
        self.test_button.clicked.connect(self.test_transformation)
        toolbox_layout.addWidget(self.test_button)

        self.test_all_button = QPushButton("Test All", self)
        self.test_all_button.clicked.connect(self.test_all_transformations)
        toolbox_layout.addWidget(self.test_all_button)

        layout.addLayout(toolbox_layout)
        self.setLayout(layout)

    def set_baseline(self):
        self.main_window.current_project.baseline = self.preview_text_area.toPlainText()
        self.main_window.statusBar().showMessage(f'Baseline changed to the transformed data')

    def show_baseline(self):
        text_lines = self.main_window.current_project.baseline.splitlines()
        self.preview_text_area.setText("\n".join(text_lines))

    def update_transformation(self, row, column):
        # Get the new value from the table
        new_value = self.transformation_table.item(row, column).text()

        # Update the corresponding transformation in the transformations list
        if column == 0:  # First column corresponds to the transformation name
            self.main_window.current_project.transformations[row]['name'] = new_value
        elif column == 1:  # Second column corresponds to the transformation code
            self.main_window.current_project.transformations[row]['code'] = new_value

        # Mark the project as modified
        self.main_window.is_project_modified = True

    def add_transformation(self):
        dialog = TransformationDialog(self)
        if dialog.exec_() == QDialog.Accepted:
            transformation_label = dialog.transformation_name
            transformation_code = dialog.transformation_code

            # Temporarily block the cellChanged signal
            self.transformation_table.blockSignals(True)

            # Add transformation to the table and project
            row_position = self.transformation_table.rowCount()
            self.transformation_table.insertRow(row_position)
            self.transformation_table.setItem(row_position, 0, QTableWidgetItem(transformation_label))
            self.transformation_table.setItem(row_position, 1, QTableWidgetItem(transformation_code))

            self.main_window.current_project.transformations.append({
                "name": transformation_label,
                "code": transformation_code
            })
            self.main_window.is_project_modified = True

            # Unblock the cellChanged signal
            self.transformation_table.blockSignals(False)

    def edit_transformation(self):
        current_row = self.transformation_table.currentRow()
        if current_row >= 0:
            transformation_label = self.transformation_table.item(current_row, 0).text()
            transformation_code = self.transformation_table.item(current_row, 1).text()

            dialog = TransformationDialog(self, transformation_name=transformation_label,
                                          transformation_code=transformation_code)
            if dialog.exec_() == QDialog.Accepted:
                updated_label = dialog.transformation_name
                updated_code = dialog.transformation_code

                # Temporarily block the cellChanged signal
                self.transformation_table.blockSignals(True)

                # Update the table and the project with the edited transformation
                self.transformation_table.setItem(current_row, 0, QTableWidgetItem(updated_label))
                self.transformation_table.setItem(current_row, 1, QTableWidgetItem(updated_code))

                self.main_window.current_project.transformations[current_row] = {
                    "name": updated_label,
                    "code": updated_code
                }
                self.main_window.is_project_modified = True

                # Unblock the cellChanged signal
                self.transformation_table.blockSignals(False)

    def delete_transformation(self):
        current_row = self.transformation_table.currentRow()
        if current_row >= 0:
            # Temporarily block the cellChanged signal
            self.transformation_table.blockSignals(True)

            # Remove the row from the table and the corresponding entry from transformations
            self.transformation_table.removeRow(current_row)
            del self.main_window.current_project.transformations[current_row]
            self.main_window.is_project_modified = True

            # Unblock the cellChanged signal
            self.transformation_table.blockSignals(False)

    def test_transformation(self):
        current_row = self.transformation_table.currentRow()
        if current_row >= 0:
            transformation = self.main_window.current_project.transformations[current_row]
            self.apply_transformation(transformation)

    def test_all_transformations(self):
        for transformation in self.main_window.current_project.transformations:
            self.apply_transformation(transformation)

    def apply_transformation(self, transformation):
        text_lines = self.main_window.current_project.text_content.splitlines()
        transformed_lines = []
        transformation_code = transformation['code']

        # Dynamically create and execute the transformation function from the code
        local_vars = {}
        try:
            exec(transformation_code, {}, local_vars)
            # Find the transformation function (assuming there's only one)
            transformation_func = next((v for k, v in local_vars.items() if callable(v)), None)
        except Exception as e:
            QMessageBox.critical(self, "Transformation Error", f"Error in transformation code: {str(e)}")
            return

        if not transformation_func:
            QMessageBox.critical(self, "Transformation Error", "No valid transformation function found in the code.")
            return

        for i in range(len(text_lines)):
            current_line = text_lines[i]
            prev_lines = text_lines[max(0, i - N):i]
            next_lines = text_lines[i + 1:min(len(text_lines), i + 1 + N)]
            try:
                transformed_line = transformation_func(current_line, prev_lines, next_lines)
                transformed_lines.append(transformed_line)
            except Exception as e:
                QMessageBox.critical(self, "Transformation Error", f"Error applying transformation: {str(e)}")
                return

        self.preview_text_area.setText("\n".join(transformed_lines))



class TransformationDialog(QDialog):
    def __init__(self, parent=None, transformation_name="", transformation_code=""):
        super().__init__(parent)
        self.transformation_name = transformation_name
        self.transformation_code = transformation_code
        self.original_code = transformation_code
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Edit Transformation" if self.transformation_name else "Add Transformation")
        self.resize(800, 300)  # Set a larger size for the dialog

        layout = QFormLayout()

        # ComboBox for transformation selection (disabled if editing)
        self.transformation_combo = QComboBox(self)
        self.transformation_combo.addItems(TRANSFORMATIONS.keys())
        layout.addRow("Select Transformation:", self.transformation_combo)

        # PyCodeEdit for Python code editing
        self.code_editor = PyCodeEdit(self)
        self.code_editor.backend.start(server.__file__)

        layout.addRow("Transformation Code:", self.code_editor)

        # Dialog buttons
        self.button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        layout.addWidget(self.button_box)

        self.setLayout(layout)

        # If editing an existing transformation, load its code
        if self.transformation_name:
            self.transformation_combo.setCurrentText(self.transformation_name)
            self.transformation_combo.setEnabled(False)  # Disable combo box when editing
            self.code_editor.setPlainText(self.transformation_code)
            self.original_code = self.transformation_code
        else:
            self.transformation_combo.currentTextChanged.connect(self.load_transformation_code)
            # Load the initial transformation code
            self.load_transformation_code(self.transformation_combo.currentText())

    def load_transformation_code(self, transformation_name):
        """Load the source code of the selected transformation."""
        if transformation_name in TRANSFORMATIONS:
            try:
                source_code = inspect.getsource(TRANSFORMATIONS[transformation_name])
                self.code_editor.setPlainText(source_code)
                self.original_code = source_code
                self.transformation_name = transformation_name
            except OSError as e:
                QMessageBox.critical(self, "Error", f"Could not retrieve source code: {str(e)}")

    def accept(self):
        current_code = self.code_editor.toPlainText()
        if current_code != self.original_code:
            # Code has been modified, assign a new name if not already editing
            if not self.transformation_name:
                base_name = self.transformation_combo.currentText() + "_Custom"
                new_name = self.generate_new_name(base_name)
                self.transformation_name = new_name
        self.transformation_code = current_code
        super().accept()

    def generate_new_name(self, base_name):
        """Generate a new transformation name if the code is customized."""
        existing_names = [trans['name'] for trans in self.parent().main_window.current_project.transformations]
        new_name = base_name
        counter = 1
        while new_name in existing_names:
            new_name = f"{base_name}_{counter}"
            counter += 1
        return new_name

    def reject(self):
        super().reject()

