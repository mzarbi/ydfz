import json

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTreeWidget, QAbstractItemView, QTextEdit, \
    QTreeWidgetItem, QComboBox, QMessageBox
from pyqode.python.backend import server
from pyqode.python.widgets import PyCodeEdit

TEMPLATES = {
    "Default": """
def parser_function(line):
    return {}
""",
    "MKV Header": """
def parser_function(line):
    # Define the tokens (keys) in the order they appear
    tokens = ["BANK", "REPORT", "PROCESSING DATE/TIME", "FOLIO", "ARCH"]
    
    parsed_dict = {}
    for idx in range(len(tokens)-1):
        first = tokens[idx]
        second = tokens[idx+1]
        
        parsed_dict[first] = line.split(first)[1].split(second)[0].strip()
        
        
    for key in parsed_dict:
        parsed_dict[key] = parsed_dict[key].strip().replace(": ", "").replace(" :", "").strip()
    
    parsed_dict["BANK_CODE"] = parsed_dict["BANK"][:2]
    parsed_dict["BANK"] = parsed_dict["BANK"][2:].strip()
    return parsed_dict""",
    "KV + ID": """

def parser_function(line):
    sps = line.split(":")
    clean = lambda x : "".join([ c if c.isalnum() else "_" for c in x ])
    return {
        clean(sps[0].strip()): " ".join(sps[1].strip().split(" ")[:1]),
        clean(sps[0].strip()) + "_ID": sps[1].strip().split(" ")[0]
    }
""",
    "KV": """
def parser_function(line):
    sps = line.split(":")
    clean = lambda x : "".join([ c if c.isalnum() else "_" for c in x ])
    return {clean(sps[0].strip()): clean(sps[1].strip())}
""",
    "Extract Numbers": """
import re
def parser_function(line):
    return {'numbers': re.findall(r'\\d+', line)}
""",
    "Extract Words": """
def parser_function(line):
    return {'words': line.split()}
""",
    "Custom Template": """
# Add your custom parser code here
def parser_function(line):
    # Example: return {'length': len(line)}
    return {}
"""
}


class ClusterTreeWidget(QTreeWidget):
    def __init__(self, parent=None):
        super().__init__(parent)

    def dropEvent(self, event):
        super().dropEvent(event)
        self.reapply_widgets()

    def reapply_widgets(self):
        def recurse_reapply(item):
            # Reapply the widgets to this item
            nesting_combo = QComboBox()
            nesting_combo.addItems(["No Children (0:0)", "Single Child (1:1)", "Multiple Children (1:N)",
                                    "Optional Multiple Children (0:N)"])
            nesting_combo.setCurrentText(
                self.itemWidget(item, 3).currentText() if self.itemWidget(item, 3) else "No Children (0:0)")
            self.setItemWidget(item, 3, nesting_combo)

            group_cardinality_combo = QComboBox()
            group_cardinality_combo.addItems(["Single (1)", "Multiple (N)", "Optional (0:1)"])
            group_cardinality_combo.setCurrentText(
                self.itemWidget(item, 4).currentText() if self.itemWidget(item, 4) else "Single (1)")
            self.setItemWidget(item, 4, group_cardinality_combo)

            sibling_relationship_combo = QComboBox()
            sibling_relationship_combo.addItems(["Ordered (Seq)", "Unordered (Unord)", "Repeatable (Rep)"])
            sibling_relationship_combo.setCurrentText(
                self.itemWidget(item, 5).currentText() if self.itemWidget(item, 5) else "Ordered (Seq)")
            self.setItemWidget(item, 5, sibling_relationship_combo)

            # Recurse for all children
            for i in range(item.childCount()):
                recurse_reapply(item.child(i))

        # Start reapplying from the top-level items
        for i in range(self.topLevelItemCount()):
            recurse_reapply(self.topLevelItem(i))


def process_cluster(cluster, data_list, current_level=0):
    current_label = cluster["label"]
    children = cluster.get("children", [])

    # Step 1: Identify lines corresponding to the current cluster
    current_lines = [(label, data) for label, data in data_list if label == current_label]

    # If this is the last level in the hierarchy (no children), return these lines
    if not children:
        return [data for _, data in current_lines]

    next_cluster = children[0]
    next_label = next_cluster["label"]

    results = []
    remaining_data = []
    last_idx = None

    # Step 2: Loop through the current cluster's lines
    for idx, (label, data) in enumerate(data_list):
        if label == current_label:
            if last_idx is not None:
                remaining_data.append(data_list[last_idx + 1:idx])
            last_idx = idx

    if last_idx is not None:
        remaining_data.append(data_list[last_idx + 1:])

    # Step 3: Merge current lines with their respective children
    for i, current_line in enumerate(current_lines):
        if i < len(remaining_data):
            child_results = process_cluster(next_cluster, remaining_data[i], current_level + 1)
            for child_data in child_results:
                results.append({**current_line[1], **child_data})

    return results


def process_hierarchies(hierarchies, data_list):
    all_results = []
    for hierarchy in hierarchies:
        results = process_cluster(hierarchy, data_list)
        all_results.extend(results)
    return all_results


class ParsingTab(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window
        self.cluster_parsers = {}
        self.initUI()

    def initUI(self):
        main_layout = QVBoxLayout()

        # Load Clusters and Text Button
        load_button_layout = QHBoxLayout()
        self.load_button = QPushButton("Load Clusters and Text", self)
        self.load_button.clicked.connect(self.load_clusters_and_text)
        load_button_layout.addWidget(self.load_button)
        main_layout.addLayout(load_button_layout)

        # Create a horizontal layout for the tree and editor
        tree_editor_layout = QHBoxLayout()

        # QTreeWidget for displaying clusters with additional columns
        self.cluster_tree = ClusterTreeWidget(self)
        self.cluster_tree.setHeaderLabels(
            ["Cluster", "Enabled", "Root", "Nesting", "Group Cardinality", "Sibling Relationship"])
        self.cluster_tree.setColumnWidth(0, 200)  # Set width for the "Cluster" column
        self.cluster_tree.setDragDropMode(QAbstractItemView.InternalMove)  # Enable drag and drop for reordering
        self.cluster_tree.itemClicked.connect(self.on_cluster_selected)
        tree_editor_layout.addWidget(self.cluster_tree)

        template_layout = QVBoxLayout()
        self.template_combo = QComboBox(self)
        self.template_combo.addItems(TEMPLATES.keys())
        self.template_combo.currentIndexChanged.connect(self.on_template_selected)
        template_layout.addWidget(self.template_combo)

        # PyQod editor for editing parser functions
        self.code_editor = PyCodeEdit(self)
        self.code_editor.backend.start(server.__file__)
        template_layout.addWidget(self.code_editor)

        tree_editor_layout.addLayout(template_layout)

        main_layout.addLayout(tree_editor_layout)

        # Two Preview Text Areas
        preview_layout = QHBoxLayout()

        self.preprocessed_text_area = QTextEdit(self)
        self.preprocessed_text_area.setReadOnly(True)
        preview_layout.addWidget(self.preprocessed_text_area)

        self.parsed_text_area = QTextEdit(self)
        self.parsed_text_area.setReadOnly(True)
        preview_layout.addWidget(self.parsed_text_area)

        main_layout.addLayout(preview_layout)

        # Button Layout
        button_layout = QHBoxLayout()

        self.save_button = QPushButton("Save Parser", self)
        self.save_button.clicked.connect(self.save_parser)
        self.save_button.setEnabled(False)
        button_layout.addWidget(self.save_button)

        self.test_button = QPushButton("Test Parser", self)
        self.test_button.clicked.connect(self.test_parser)
        self.test_button.setEnabled(False)
        button_layout.addWidget(self.test_button)

        self.clear_button = QPushButton("Clear Parser", self)
        self.clear_button.clicked.connect(self.clear_parser)
        self.clear_button.setEnabled(False)
        button_layout.addWidget(self.clear_button)

        self.run_all_button = QPushButton("Run All Parsers", self)
        self.run_all_button.clicked.connect(self.run_all_parsers)
        button_layout.addWidget(self.run_all_button)


        self.parse_button = QPushButton("Parse", self)
        self.parse_button.clicked.connect(self.parse_hierarchy)
        button_layout.addWidget(self.parse_button)

        self.hierarchy_button = QPushButton("Hierarchy", self)
        self.hierarchy_button.clicked.connect(self.hierarchy_display)
        button_layout.addWidget(self.hierarchy_button)

        main_layout.addLayout(button_layout)

        self.setLayout(main_layout)

    def on_template_selected(self, index):
        """Update the code editor when a template is selected."""
        template_name = self.template_combo.currentText()
        if template_name in TEMPLATES:
            self.code_editor.setPlainText(TEMPLATES[template_name])

    def save_state_to_project(self):
        """Save the current state of the parsing tab to the project."""
        self.main_window.current_project.cluster_parsers = self.cluster_parsers
        self.main_window.current_project.cluster_tree_structure = self.get_tree_structure()

    def load_content_from_project(self):
        """Load the saved state of the parsing tab from the project."""
        self.cluster_parsers = self.main_window.current_project.cluster_parsers
        self.load_tree_structure(self.main_window.current_project.cluster_tree_structure)

    def get_tree_structure(self):
        """Recursively retrieve the tree structure."""

        def recurse_tree(item):
            children = []
            for i in range(item.childCount()):
                child = item.child(i)
                children.append(recurse_tree(child))
            return {
                "label": item.text(0),
                "enabled": item.checkState(1) == Qt.Checked,
                "root": item.checkState(2) == Qt.Checked,
                #"nesting": self.cluster_tree.itemWidget(item, 3).currentText(),
                #"group_cardinality": self.cluster_tree.itemWidget(item, 4).currentText(),
                #"sibling_relationship": self.cluster_tree.itemWidget(item, 5).currentText(),
                "children": children
            }

        tree_structure = []
        for i in range(self.cluster_tree.topLevelItemCount()):
            item = self.cluster_tree.topLevelItem(i)
            tree_structure.append(recurse_tree(item))
        return tree_structure

    def load_tree_structure(self, structure, parent_item=None):
        """Recursively load the tree structure."""

        def recurse_load(item_structure, parent_item):
            item = QTreeWidgetItem(parent_item, [item_structure["label"]])
            item.setCheckState(1, Qt.Checked if item_structure["enabled"] else Qt.Unchecked)
            item.setCheckState(2, Qt.Checked if item_structure["root"] else Qt.Unchecked)

            # Nesting ComboBox
            nesting_combo = QComboBox()
            nesting_combo.addItems(["No Children (0:0)", "Single Child (1:1)", "Multiple Children (1:N)",
                                    "Optional Multiple Children (0:N)"])
            nesting_combo.setCurrentText(item_structure["nesting"])
            self.cluster_tree.setItemWidget(item, 3, nesting_combo)

            # Group Cardinality ComboBox
            group_cardinality_combo = QComboBox()
            group_cardinality_combo.addItems(["Single (1)", "Multiple (N)", "Optional (0:1)"])
            group_cardinality_combo.setCurrentText(item_structure["group_cardinality"])
            self.cluster_tree.setItemWidget(item, 4, group_cardinality_combo)

            # Sibling Relationship ComboBox
            sibling_relationship_combo = QComboBox()
            sibling_relationship_combo.addItems(["Ordered (Seq)", "Unordered (Unord)", "Repeatable (Rep)"])
            sibling_relationship_combo.setCurrentText(item_structure["sibling_relationship"])
            self.cluster_tree.setItemWidget(item, 5, sibling_relationship_combo)

            if parent_item is None:
                self.cluster_tree.addTopLevelItem(item)
            for child in item_structure["children"]:
                recurse_load(child, item)

        self.cluster_tree.clear()
        for item_structure in structure:
            recurse_load(item_structure, parent_item=None)

    def load_clusters_and_text(self):
        """Load clusters and preprocessed text from the ClusteringTab."""
        clustering_tab = self.main_window.clustering_tab

        # Load clusters into the tree
        clusters = clustering_tab.cluster_parser.tagged_lines['Cluster'].unique()
        self.load_clusters(clusters)

        # Load preprocessed text
        preprocessed_text = self.get_preprocessed_text()
        self.preprocessed_text_area.setPlainText("\n".join(preprocessed_text))

    def load_clusters(self, clusters):
        """Load clusters into the tree."""
        self.cluster_tree.clear()
        for cluster in clusters:
            item = QTreeWidgetItem(self.cluster_tree, [f"Cluster {cluster}"])
            item.setCheckState(1, Qt.Checked)  # Default "Enabled" to false
            item.setCheckState(2, Qt.Unchecked)  # Default "Root" to false

            # Nesting ComboBox
            nesting_combo = QComboBox()
            nesting_combo.addItems(["No Children (0:0)", "Single Child (1:1)", "Multiple Children (1:N)",
                                    "Optional Multiple Children (0:N)"])
            nesting_combo.setCurrentText("No Children (0:0)")  # Default to "No Children"
            self.cluster_tree.setItemWidget(item, 3, nesting_combo)

            # Group Cardinality ComboBox
            group_cardinality_combo = QComboBox()
            group_cardinality_combo.addItems(["Single (1)", "Multiple (N)", "Optional (0:1)"])
            group_cardinality_combo.setCurrentText("Single (1)")
            self.cluster_tree.setItemWidget(item, 4, group_cardinality_combo)

            # Sibling Relationship ComboBox
            sibling_relationship_combo = QComboBox()
            sibling_relationship_combo.addItems(["Ordered (Seq)", "Unordered (Unord)", "Repeatable (Rep)"])
            sibling_relationship_combo.setCurrentText("Ordered (Seq)")
            self.cluster_tree.setItemWidget(item, 5, sibling_relationship_combo)

            self.cluster_tree.addTopLevelItem(item)
            if cluster not in self.cluster_parsers:
                self.cluster_parsers[cluster] = self.default_parser_function()

    def default_parser_function(self):
        """Returns the default parser function code."""
        return """
def parser_function(line):
    return {}
"""

    def on_cluster_selected(self, item, column):
        """Load the parser function for the selected cluster."""
        cluster_label = item.text(0)
        cluster_id = int(cluster_label.split(" ")[1])
        self.code_editor.setPlainText(self.cluster_parsers[cluster_id])
        self.save_button.setEnabled(True)
        self.test_button.setEnabled(True)
        self.clear_button.setEnabled(True)

        try:
            tagged_lines = self.main_window.current_project.clustering_model["tagged_lines"]
            tagged_lines = tagged_lines[tagged_lines['Cluster'] == int(cluster_id)]["Line"].tolist()

            self.parsed_text_area.setPlainText("\n".join(str(result) for result in tagged_lines))
        except Exception as e:
            print(e)

    def save_parser(self):
        """Save the current code from the editor as the parser function for the selected cluster."""
        selected_item = self.cluster_tree.currentItem()
        if selected_item:
            cluster_label = selected_item.text(0)
            cluster_id = int(cluster_label.split(" ")[1])
            self.cluster_parsers[cluster_id] = self.code_editor.toPlainText()

    def test_parser(self):
        """Test the parser function on lines of the selected cluster."""
        selected_item = self.cluster_tree.currentItem()
        if selected_item:
            cluster_label = selected_item.text(0)
            cluster_id = int(cluster_label.split(" ")[1])
            parser_code = self.cluster_parsers[cluster_id]
            parser_func = self.evaluate_code(parser_code)

            if parser_func:
                preprocessed_text = self.preprocessed_text_area.toPlainText().splitlines()
                tagged_lines = self.main_window.clustering_tab.cluster_parser.tagged_lines
                cluster_lines = tagged_lines[tagged_lines['Cluster'] == cluster_id]['Line']
                parsed_results = [parser_func(line) for line in cluster_lines]
                self.parsed_text_area.setPlainText("\n".join(str(result) for result in parsed_results))

    def clear_parser(self):
        """Reset the parser function to the default for the selected cluster."""
        selected_item = self.cluster_tree.currentItem()
        if selected_item:
            cluster_label = selected_item.text(0)
            cluster_id = int(cluster_label.split(" ")[1])
            self.cluster_parsers[cluster_id] = self.default_parser_function()
            self.code_editor.setPlainText(self.cluster_parsers[cluster_id])

    def hierarchy_display(self):
        self.parsed_text_area.setPlainText(json.dumps(self.get_tree_structure(), indent=5))

    def parse_hierarchy(self):
        """Parse the lines according to the hierarchy defined in the tree."""

        try:
            tagged_lines = self.main_window.clustering_tab.cluster_parser.tagged_lines
            data_list = []

            for _, row in tagged_lines.iterrows():
                cluster_id = row['Cluster']
                line = row['Line']
                if cluster_id in self.cluster_parsers:
                    parser_code = self.cluster_parsers[cluster_id]
                    parser_func = self.evaluate_code(parser_code)

                    if parser_func:
                        parsed_result = parser_func(line)
                        data_list.append((f"Cluster {row['Cluster']}", parsed_result))


            hierarchies = self.get_tree_structure()

            results = process_hierarchies(hierarchies, data_list)
            self.parsed_text_area.setPlainText("\n".join(str(result) for result in results))
        except Exception as e:print(e)


    def run_all_parsers(self):
        """Run all parser functions on their respective clusters and display the results."""
        tagged_lines = self.main_window.clustering_tab.cluster_parser.tagged_lines
        parsed_results = []

        for _, row in tagged_lines.iterrows():
            cluster_id = row['Cluster']
            line = row['Line']

            if cluster_id in self.cluster_parsers:
                parser_code = self.cluster_parsers[cluster_id]
                parser_func = self.evaluate_code(parser_code)

                if parser_func:
                    parsed_result = parser_func(line)
                    parsed_results.append(parsed_result)

        self.parsed_text_area.setPlainText("\n".join(str(result) for result in parsed_results))

    def evaluate_code(self, code):
        """Evaluate the provided code as a function."""
        try:
            exec(code, globals())
            return eval('parser_function')
        except Exception as e:
            QMessageBox.critical(self, "Code Error", f"Error in the code:\n{str(e)}")
            return None

    def get_preprocessed_text(self):
        """Get the preprocessed text."""
        return self.main_window.preprocessing_tab.execute_operations()
