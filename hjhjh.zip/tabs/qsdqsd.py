import pickle

with open(r"C:\Users\medzi\Desktop\bnp\srms-pp\tests\EA0802_17042023.txt", 'r', encoding='utf-8') as file:
    file_content = file.read()


with open(r"C:\Users\medzi\Desktop\bnp\srms-pp\tests\EA802_STNDLN.pkl", "rb") as f:
    parser = pickle.load(f)

parsed_results = parser.process(file_content)
for tmp in parsed_results:
    print(tmp)