from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QSplitter, QTextEdit, QTableWidget, QHBoxLayout, QPushButton, QDialog, \
    QTableWidgetItem, QMessageBox, QFormLayout, QLineEdit, QDialogButtonBox, QHeaderView
from pyqode.python.backend import server
from pyqode.python.widgets import PyCodeEdit

from tabs.utils import N


class ReductionTab(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        # Create a splitter to hold the preview area and the table
        splitter = QSplitter(Qt.Horizontal)

        # Preview area
        self.preview_text_area = QTextEdit(self)
        self.preview_text_area.setReadOnly(True)
        splitter.addWidget(self.preview_text_area)

        # Table for storing reductions
        self.reduction_table = QTableWidget(0, 2, self)
        self.reduction_table.setHorizontalHeaderLabels(["Reduction Name", "Function"])

        header = self.reduction_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Stretch)

        # Connect the cellChanged signal to update_reduction slot
        self.reduction_table.cellChanged.connect(self.update_reduction)

        splitter.addWidget(self.reduction_table)

        # Set the initial sizes for the splitter
        splitter.setStretchFactor(0, 7)  # 70% for the preview area
        splitter.setStretchFactor(1, 3)  # 30% for the table

        layout.addWidget(splitter)

        # Reduction Toolbox
        toolbox_layout = QHBoxLayout()

        self.show_raw_button = QPushButton("Show Baseline", self)
        self.show_raw_button.clicked.connect(self.show_baseline)
        toolbox_layout.addWidget(self.show_raw_button)

        self.set_baseline_button = QPushButton("Set Baseline", self)
        self.set_baseline_button.clicked.connect(self.set_baseline)
        toolbox_layout.addWidget(self.set_baseline_button)

        self.add_button = QPushButton("Add Reduction", self)
        self.add_button.clicked.connect(self.add_reduction)
        toolbox_layout.addWidget(self.add_button)

        self.pos_exclusion_button = QPushButton("POS", self)
        self.pos_exclusion_button.clicked.connect(self.add_pos_exclusion)
        toolbox_layout.addWidget(self.pos_exclusion_button)

        self.delete_button = QPushButton("Delete Reduction", self)
        self.delete_button.clicked.connect(self.delete_reduction)
        toolbox_layout.addWidget(self.delete_button)

        self.edit_button = QPushButton("Edit Reduction", self)
        self.edit_button.clicked.connect(self.edit_reduction)
        toolbox_layout.addWidget(self.edit_button)

        self.test_button = QPushButton("Test Reduction", self)
        self.test_button.clicked.connect(self.test_reduction)
        toolbox_layout.addWidget(self.test_button)

        self.test_all_button = QPushButton("Test All", self)
        self.test_all_button.clicked.connect(self.test_all_reductions)
        toolbox_layout.addWidget(self.test_all_button)

        layout.addLayout(toolbox_layout)
        self.setLayout(layout)

    def set_baseline(self):
        self.main_window.current_project.baseline = self.preview_text_area.toPlainText()
        self.main_window.statusBar().showMessage(f'Baseline changed to the exclusions data')

    def show_baseline(self):
        """Display the raw text from the project in the preview area."""
        raw_text = self.main_window.current_project.baseline
        self.preview_text_area.setText(raw_text)

    def update_reduction(self, row, column):
        # Get the new value from the table
        new_value = self.reduction_table.item(row, column).text()

        # Update the corresponding reduction in the reductions list
        if column == 0:  # First column corresponds to the reduction name
            self.main_window.current_project.reductions[row]['name'] = new_value
        elif column == 1:  # Second column corresponds to the reduction code
            self.main_window.current_project.reductions[row]['code'] = new_value

        # Mark the project as modified
        self.main_window.is_project_modified = True

    def add_reduction(self):
        dialog = ReductionDialog(self)
        if dialog.exec_() == QDialog.Accepted:
            reduction_name = dialog.reduction_name
            reduction_code = dialog.reduction_code

            try:
                # Temporarily block the cellChanged signal
                self.reduction_table.blockSignals(True)

                # Add reduction to the table and project
                row_position = self.reduction_table.rowCount()
                self.reduction_table.insertRow(row_position)
                self.reduction_table.setItem(row_position, 0, QTableWidgetItem(reduction_name))
                self.reduction_table.setItem(row_position, 1, QTableWidgetItem(reduction_code))

                self.main_window.current_project.reductions.append({
                    "name": reduction_name,
                    "code": reduction_code
                })
                self.main_window.is_project_modified = True

                # Unblock the cellChanged signal
                self.reduction_table.blockSignals(False)
            except Exception as e:
                print(e)

    def add_pos_exclusion(self):
        selected_text = self.preview_text_area.textCursor().selectedText()
        dialog = ReductionDialog(self, reduction_code=self.get_pos_exclusion_template(selected_text))
        if dialog.exec_() == QDialog.Accepted:
            reduction_name = dialog.reduction_name
            reduction_code = dialog.reduction_code

            # Temporarily block the cellChanged signal
            self.reduction_table.blockSignals(True)

            # Add reduction to the table and project
            row_position = self.reduction_table.rowCount()
            self.reduction_table.insertRow(row_position)
            self.reduction_table.setItem(row_position, 0, QTableWidgetItem(reduction_name))
            self.reduction_table.setItem(row_position, 1, QTableWidgetItem(reduction_code))

            self.main_window.current_project.reductions.append({
                "name": reduction_name,
                "code": reduction_code
            })
            self.main_window.is_project_modified = True

            # Unblock the cellChanged signal
            self.reduction_table.blockSignals(False)

    def get_pos_exclusion_template(self, selected_text=""):
        """Return a template function for POS exclusion."""
        return f"""def reduction_function(current_line, prev_lines, next_lines):
    # This function excludes lines containing the specified string
    exclusion_string = "{selected_text}"
    return exclusion_string not in current_line
"""
    def delete_reduction(self):
        current_row = self.reduction_table.currentRow()
        if current_row >= 0:
            # Temporarily block the cellChanged signal
            self.reduction_table.blockSignals(True)

            # Remove the row from the table and the corresponding entry from reductions
            self.reduction_table.removeRow(current_row)
            del self.main_window.current_project.reductions[current_row]
            self.main_window.is_project_modified = True

            # Unblock the cellChanged signal
            self.reduction_table.blockSignals(False)

    def edit_reduction(self):
        current_row = self.reduction_table.currentRow()
        if current_row >= 0:
            reduction = self.main_window.current_project.reductions[current_row]
            dialog = ReductionDialog(self, reduction['name'], reduction['code'])
            if dialog.exec_() == QDialog.Accepted:
                # Temporarily block the cellChanged signal
                self.reduction_table.blockSignals(True)

                # Update the reduction in the table and project
                self.reduction_table.setItem(current_row, 0, QTableWidgetItem(dialog.reduction_name))
                self.reduction_table.setItem(current_row, 1, QTableWidgetItem(dialog.reduction_code))

                self.main_window.current_project.reductions[current_row] = {
                    "name": dialog.reduction_name,
                    "code": dialog.reduction_code
                }
                self.main_window.is_project_modified = True

                # Unblock the cellChanged signal
                self.reduction_table.blockSignals(False)

    def test_reduction(self):
        current_row = self.reduction_table.currentRow()
        if current_row >= 0:
            reduction = self.main_window.current_project.reductions[current_row]
            self.apply_reduction(reduction)

    def test_all_reductions(self):
        """Apply all reductions in sequence, chaining the results."""
        text_lines = self.main_window.current_project.baseline.splitlines()

        for reduction in self.main_window.current_project.reductions:
            text_lines = self.apply_reduction(reduction, text_lines)

        # Update the preview area with the final reduced text
        reduced_lines = [line for line in text_lines if line.strip()]
        self.preview_text_area.setText("\n".join(reduced_lines))

    def apply_reduction(self, reduction, text_lines=None):
        """Apply a single reduction to the provided text lines."""
        if text_lines is None:
            text_lines = self.main_window.current_project.baseline.splitlines()

        reduced_lines = []

        reduction_func = self.evaluate_code(reduction['code'])

        if not reduction_func:
            QMessageBox.critical(self, "Reduction Error",
                                 f"Reduction function {reduction['name']} could not be evaluated.")
            return text_lines

        for i in range(len(text_lines)):
            current_line = text_lines[i]
            prev_lines = text_lines[max(0, i - N):i]
            next_lines = text_lines[i + 1:min(len(text_lines), i + 1 + N)]
            if reduction_func(current_line, prev_lines, next_lines):
                reduced_lines.append(current_line)

        return reduced_lines

    def evaluate_code(self, code):
        """Evaluate the provided code as a function."""
        try:
            exec(code, globals())
            return eval('reduction_function')
        except Exception as e:
            QMessageBox.critical(self, "Code Error", f"Error in the code:\n{str(e)}")
            return None



class ReductionDialog(QDialog):
    _reduction_counter = 1  # Class variable to keep track of the number of reductions

    def __init__(self, parent=None, reduction_name="", reduction_code=""):
        super().__init__(parent)
        if reduction_name:
            self.reduction_name = reduction_name
        else:
            self.reduction_name = f"Reduction_{ReductionDialog._reduction_counter}"
            ReductionDialog._reduction_counter += 1

        self.reduction_code = reduction_code if reduction_code else self.get_default_template()
        self.initUI()

    def initUI(self):
        layout = QFormLayout()

        # LineEdit for reduction name
        self.reduction_name_edit = QLineEdit(self)
        self.reduction_name_edit.setText(self.reduction_name)
        layout.addRow("Reduction Name:", self.reduction_name_edit)

        # PyCodeEdit for Python code editing
        self.code_editor = PyCodeEdit(self)
        self.code_editor.backend.start(server.__file__)
        self.code_editor.setPlainText(self.reduction_code)

        layout.addRow("Reduction Code:", self.code_editor)

        # Dialog buttons
        self.button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        layout.addWidget(self.button_box)

        self.setLayout(layout)
        self.resize(800, 300)

    def get_default_template(self):
        return """def reduction_function(current_line, prev_lines, next_lines):
    # Edit this function to implement your reduction logic
    return True
"""

    def accept(self):
        self.reduction_name = self.reduction_name_edit.text()
        self.reduction_code = self.code_editor.toPlainText()
        super().accept()

    def reject(self):
        super().reject()
