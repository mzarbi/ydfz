import pickle
import re
import sys
import numpy as np
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTextEdit, QFileDialog, QMessageBox
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import FeatureUnion

from tabs.parsing import process_hierarchies
import pandas as pd


import pickle

class WeightedFeatureExtractor(BaseEstimator, TransformerMixin):
    def __init__(self, transformer, weight=100.0):
        self.transformer = transformer
        self.weight = weight

    def fit(self, X, y=None):
        self.transformer.fit(X, y)
        return self

    def transform(self, X):
        return self.transformer.transform(X) * self.weight


class ParserModel:
    def __init__(self, preprocessing_steps, transformations, reductions, translations, clustering_model,
                 parsing_hierarchy, cluster_parsers, extractors):
        self.preprocessing_steps = preprocessing_steps
        self.transformations = transformations
        self.reductions = reductions
        self.translations = translations
        self.clustering_model = clustering_model
        self.parsing_hierarchy = parsing_hierarchy
        self.cluster_parsers = cluster_parsers
        self.extractors = extractors
        self.additional_features = []

    def preprocess(self, text):
        """Apply preprocessing steps to the text."""
        text_lines = text.splitlines()

        for operation in self.preprocessing_steps:
            operation_type = operation["type"]
            name = operation["name"]

            if operation_type == "Transformation":
                op = next((t for t in self.transformations if t['name'] == name), None)
                if op:
                    text_lines = self.apply_transformation(op, text_lines)
            elif operation_type == "Reduction":
                op = next((r for r in self.reductions if r['name'] == name), None)
                if op:
                    text_lines = self.apply_reduction(op, text_lines)
            elif operation_type == "Translation":
                op = next((tr for tr in self.translations if tr['original_word'] == name), None)
                if op:
                    text_lines = self.apply_translation(op, text_lines)

        return text_lines

    def apply_transformation(self, transformation, text_lines):
        """Apply a transformation to the text lines."""
        transformed_lines = []
        transformation_func = self.evaluate_code(transformation['code'])

        if not transformation_func:
            raise ValueError(f"Transformation function {transformation['name']} could not be evaluated.")

        for i in range(len(text_lines)):
            current_line = text_lines[i]
            prev_lines = text_lines[max(0, i - 3):i]  # Assuming N=3, adjust accordingly
            next_lines = text_lines[i + 1:min(len(text_lines), i + 4)]
            transformed_line = transformation_func(current_line, prev_lines, next_lines)
            transformed_lines.append(transformed_line)

        return transformed_lines

    def apply_reduction(self, reduction, text_lines):
        """Apply a reduction to the text lines."""
        reduced_lines = []
        reduction_func = self.evaluate_code(reduction['code'])

        if not reduction_func:
            raise ValueError(f"Reduction function {reduction['name']} could not be evaluated.")

        for i in range(len(text_lines)):
            current_line = text_lines[i]
            prev_lines = text_lines[max(0, i - 3):i]
            next_lines = text_lines[i + 1:min(len(text_lines), i + 4)]
            if reduction_func(current_line, prev_lines, next_lines):
                reduced_lines.append(current_line)

        return reduced_lines

    def apply_translation(self, translation, text_lines):
        """Apply a translation to the text lines."""
        return [line.replace(translation['original_word'], translation['replacement_word']) for line in text_lines]

    def evaluate_parser(self, code):
        """Evaluate the provided code as a function."""
        try:
            exec(code, globals())
            return eval('parser_function')
        except Exception as e:
            QMessageBox.critical(self, "Code Error", f"Error in the code:\n{str(e)}")
            return None
    def evaluate_code(self, code):
        """Evaluate the provided code as a function."""
        try:
            exec(code, globals())
            func_name = self.get_function_name(code)
            return eval(func_name)
        except Exception as e:
            raise ValueError(f"Error in the code:\n{str(e)}")

    def get_function_name(self, python_string):
        """Extract the function name from the code."""
        match = re.search(r'def\s+(\w+)\s*\(', python_string)
        if match:
            return match.group(1)
        return None

    def create_transformer(self, feature_code):
        """Dynamically create a transformer from the provided code."""
        local_vars = {}
        exec(feature_code, globals(), local_vars)


        transformer_class_name = list(local_vars.keys())[0]
        current_module = sys.modules[__name__]
        setattr(current_module, transformer_class_name, local_vars[transformer_class_name])

        return getattr(current_module, transformer_class_name)()

    def predict_clusters(self, preprocessed_text):
        """Predict clusters using the clustering model."""

        for extractor in self.extractors:
            # Recreate the feature extractor
            transformer = self.create_transformer(extractor["code"])
            self.additional_features.append(
                (extractor["name"], WeightedFeatureExtractor(transformer, extractor["weight"]))
            )

        feature_union = FeatureUnion(self.additional_features + [('vectorizer', self.clustering_model["vectorizer"])])

        new_X_features = feature_union.transform(preprocessed_text)
        new_X_pca = self.clustering_model["reducer"].transform(new_X_features)
        new_labels = self.clustering_model["clusterer"].predict(new_X_pca)

        return pd.DataFrame({'Line': preprocessed_text, 'Cluster': new_labels})

    def parse(self, tagged_lines):
        """Parse the tagged lines according to the hierarchy."""
        data_list = []

        for _, row in tagged_lines.iterrows():
            cluster_id = row['Cluster']
            line = row['Line']
            if cluster_id in self.cluster_parsers:
                parser_code = self.cluster_parsers[cluster_id]
                parser_func = self.evaluate_parser(parser_code)

                if parser_func:
                    parsed_result = parser_func(line)
                    data_list.append((f"Cluster {row['Cluster']}", parsed_result))

        results = process_hierarchies(self.parsing_hierarchy, data_list)
        return results

    def process(self, text):
        """Complete processing: preprocess, predict, and parse."""
        preprocessed_text = self.preprocess(text)
        tagged_lines = self.predict_clusters(preprocessed_text)
        parsed_results = self.parse(tagged_lines)
        return parsed_results

    def save(self, filename):
        """Save the entire model as a pickle file."""
        with open(filename, 'wb') as file:
            pickle.dump(self, file)

    @staticmethod
    def load(filename):
        """Load a model from a pickle file."""
        with open(filename, 'rb') as file:
            return pickle.load(file)

class TestingTab(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window
        self.initUI()

    def initUI(self):
        main_layout = QVBoxLayout()

        # Testing Section
        testing_layout = QVBoxLayout()
        self.test_button = QPushButton("Test Against File", self)
        self.test_button.clicked.connect(self.test_against_file)
        testing_layout.addWidget(self.test_button)

        self.test_output_area = QTextEdit(self)
        self.test_output_area.setReadOnly(True)
        testing_layout.addWidget(self.test_output_area)

        main_layout.addLayout(testing_layout)

        # Export Section
        export_layout = QVBoxLayout()
        self.export_button = QPushButton("Export Standalone Parser", self)
        self.export_button.clicked.connect(self.export_parser)
        export_layout.addWidget(self.export_button)

        main_layout.addLayout(export_layout)

        self.setLayout(main_layout)

    def test_against_file(self):
        options = QFileDialog.Options()
        file_name, _ = QFileDialog.getOpenFileName(self, "Open Test File", "", "Text Files (*.txt);;All Files (*)", options=options)
        if file_name:
            try:
                with open(file_name, 'r', encoding='utf-8') as file:
                    file_content = file.read()

                # Create a ParserModel instance from the current project
                parser_model = self.create_parser_model()

                # Process the file content using the parser model
                parsed_results = parser_model.process(file_content)

                # Display the parsed results in the text area
                self.test_output_area.setPlainText("\n".join(str(result) for result in parsed_results))
            except Exception as e:
                QMessageBox.critical(self, "Error", f"An error occurred while testing the file:\n{str(e)}")

    def create_parser_model(self):
        """Create a ParserModel instance using the current project settings."""
        preprocessing_steps = self.main_window.current_project.preprocessing_order
        transformations = self.main_window.current_project.transformations
        reductions = self.main_window.current_project.reductions
        translations = self.main_window.current_project.translations
        clustering_model_data = self.main_window.current_project.clustering_model


        parsing_hierarchy = self.main_window.parsing_tab.get_tree_structure()
        cluster_parsers = self.main_window.parsing_tab.cluster_parsers
        extractors = self.main_window.current_project.feature_extractors
        return ParserModel(preprocessing_steps, transformations, reductions, translations, clustering_model_data, parsing_hierarchy, cluster_parsers, extractors)

    def export_parser(self):
        options = QFileDialog.Options()
        file_name, _ = QFileDialog.getSaveFileName(self, "Save Standalone Parser", "", "Pickle Files (*.pkl);;All Files (*)", options=options)
        if file_name:
            try:
                # Create a ParserModel instance and save it as a pickle file
                parser_model = self.create_parser_model()
                parser_model.save(file_name)
                QMessageBox.information(self, "Success", f"Standalone parser exported to {file_name}")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"An error occurred while exporting the parser:\n{str(e)}")
