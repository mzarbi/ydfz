from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QTextEdit, QFileDialog, QMessageBox, \
    QHBoxLayout


class TextFileTab(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        # Read-only LineEdit to display filename
        self.filename_label = QLabel("Loaded File:")
        layout.addWidget(self.filename_label)

        ext_area_layout = QHBoxLayout()

        self.filename_display = QLineEdit(self)
        self.filename_display.setReadOnly(True)
        ext_area_layout.addWidget(self.filename_display)

        # Button to load a file
        self.load_button = QPushButton('Load File', self)
        self.load_button.clicked.connect(self.load_file)
        ext_area_layout.addWidget(self.load_button)

        self.set_baseline_button = QPushButton('Set Baseline', self)
        self.set_baseline_button.clicked.connect(self.set_baseline)
        ext_area_layout.addWidget(self.set_baseline_button)

        layout.addLayout(ext_area_layout)

        # Text area to display file content
        self.text_area = QTextEdit(self)
        layout.addWidget(self.text_area)

        self.setLayout(layout)

    def set_baseline(self):
        self.main_window.current_project.baseline = self.main_window.current_project.text_content
        self.main_window.statusBar().showMessage(f'Baseline changed to the raw data')

    def load_file(self):
        options = QFileDialog.Options()
        file_name, _ = QFileDialog.getOpenFileName(self, "Open Text File", "", "Text Files (*.txt);;All Files (*)",
                                                   options=options)
        if file_name:
            try:
                with open(file_name, 'r', encoding='utf-8') as file:
                    lines = file.readlines()
                    non_empty_lines = [line.replace('\n', '') for line in lines if line.strip()]
                    content = "\n".join(non_empty_lines)
                    self.text_area.setText(content)

                    # Update project information
                    self.main_window.current_project.loaded_filename = file_name
                    self.main_window.current_project.text_content = content
                    self.main_window.current_project.baseline = content
                    self.main_window.is_project_modified = True

                    # Update filename display
                    self.filename_display.setText(file_name)

                    self.main_window.statusBar().showMessage(f'Loaded file: {file_name}')
            except Exception as e:
                QMessageBox.critical(self, "Load Error", f"An error occurred while loading the file:\n{str(e)}")

    def save_state_to_project(self):
        """Save the current state of this tab to the project."""
        self.main_window.current_project.text_content = self.text_area.toPlainText()
        self.main_window.current_project.loaded_filename = self.filename_display.text()

    def load_content_from_project(self):
        """Load the content of the text area from the current project."""
        self.text_area.setText(self.main_window.current_project.text_content)
        if self.main_window.current_project.loaded_filename:
            self.filename_display.setText(self.main_window.current_project.loaded_filename)

