import pickle
import sys

from PyQt5.QtGui import QColor
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QTextEdit, QTextBrowser, QTableWidget, QPushButton, \
    QLabel, QLineEdit, QTableWidgetItem, QDialog, QMessageBox, QFormLayout, QComboBox, QDialogButtonBox, QHeaderView
from pyqode.python.backend import server
from pyqode.python.widgets import PyCodeEdit
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.cluster import KMeans
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import silhouette_score
from sklearn.pipeline import FeatureUnion
import pandas as pd
import numpy as np

FEATURE_EXTRACTORS = {
    "Length Feature": """
class LengthFeatureExtractor(BaseEstimator, TransformerMixin):
    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return np.array([[len(text)] for text in X])
""",
    "Word Existence Feature": """
class WordExistenceFeatureExtractor(BaseEstimator, TransformerMixin):
    def __init__(self):
        self.words = []

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return np.array([[1 if word in text else 0 for word in self.words] for text in X])
""",
    "Custom Feature (Empty Template)": """
class CustomFeatureExtractor(BaseEstimator, TransformerMixin):
    def __init__(self):
        # Initialize any parameters here
        pass

    def fit(self, X, y=None):
        # Implement fitting logic if necessary
        return self

    def transform(self, X):
        # Implement the feature extraction logic here
        # Return a numpy array with the extracted features
        return np.array([[0] for _ in X])
"""
}

class WeightedFeatureExtractor(BaseEstimator, TransformerMixin):
    def __init__(self, transformer, weight=100.0):
        self.transformer = transformer
        self.weight = weight

    def fit(self, X, y=None):
        self.transformer.fit(X, y)
        return self

    def transform(self, X):
        return self.transformer.transform(X) * self.weight


class TextClusterParser:
    def __init__(self, n_clusters=10, pca_variance=0.95, random_state=42):
        self.pca_variance = pca_variance
        self.n_clusters = n_clusters
        self.random_state = random_state
        self.additional_features = []
        self.feature_union = None
        self.fitted = False
        self.labels = None
        self.tagged_lines = None
        self.silhouette_avg = None
        self.initialize()

    def initialize(self):
        self.vectorizer = TfidfVectorizer()
        self.reducer = TruncatedSVD(n_components=int(self.pca_variance * 100))
        self.clusterer = KMeans(n_clusters=self.n_clusters, random_state=self.random_state)

    def add_feature_extractor(self, feature_name, transformer, weight=100.0):
        self.additional_features.append(
            (feature_name, WeightedFeatureExtractor(transformer, weight))
        )

    def fit(self, lines):
        combined_data = pd.DataFrame({'Line': lines})
        self.feature_union = FeatureUnion(self.additional_features + [('vectorizer', self.vectorizer)])

        # Step 1: Feature Extraction
        X_features = self.feature_union.fit_transform(combined_data['Line'])

        # Step 2: Dimensionality Reduction
        X_pca = self.reducer.fit_transform(X_features)

        # Step 3: Clustering
        self.labels = self.clusterer.fit_predict(X_pca)
        self.silhouette_avg = silhouette_score(X_pca, self.labels)

        # Step 4: Tagging and Result Display
        self.tagged_lines = pd.DataFrame({'Line': lines, 'Cluster': self.labels})
        self.fitted = True

        return self.tagged_lines

    def predict(self, new_lines):
        if not self.fitted:
            raise ValueError("The model must be fitted before predicting.")

        new_X_features = self.feature_union.transform(pd.DataFrame({'Line': new_lines})['Line'])
        new_X_pca = self.reducer.transform(new_X_features)
        new_labels = self.clusterer.predict(new_X_pca)

        return pd.DataFrame({'Line': new_lines, 'Cluster': new_labels})

    def inspect_cluster(self, cluster_number):
        if not self.fitted:
            raise ValueError("The model must be fitted before inspecting clusters.")
        return self.tagged_lines[self.tagged_lines['Cluster'] == cluster_number]['Line'].tolist()


class FeatureExtractorDialog(QDialog):
    def __init__(self, parent=None, feature_name="", feature_code="", weight=100.0, word_example="WORD_EXAMPLE"):
        super().__init__(parent)
        self.feature_name = feature_name
        self.feature_code = feature_code
        self.weight = weight
        self.word_example = word_example
        self.initUI()

    def initUI(self):
        layout = QFormLayout()

        # LineEdit for feature name
        self.feature_name_edit = QLineEdit(self)
        self.feature_name_edit.setText(self.feature_name)
        layout.addRow("Feature Name:", self.feature_name_edit)

        # ComboBox for selecting a predefined template
        self.template_combo = QComboBox(self)
        self.template_combo.addItems(FEATURE_EXTRACTORS.keys())
        self.template_combo.currentIndexChanged.connect(self.load_template)
        layout.addRow("Select Template:", self.template_combo)

        # PyQod editor for Python code editing
        self.code_editor = PyCodeEdit(self)
        self.code_editor.backend.start(server.__file__)
        self.code_editor.setPlainText(self.feature_code)
        layout.addRow("Feature Code:", self.code_editor)

        # LineEdit for weight
        self.weight_edit = QLineEdit(self)
        self.weight_edit.setText(str(self.weight))
        layout.addRow("Weight:", self.weight_edit)

        # Dialog buttons
        self.button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        layout.addWidget(self.button_box)

        self.setLayout(layout)
        self.resize(800, 300)

    def load_template(self):
        template_name = self.template_combo.currentText()
        if template_name in FEATURE_EXTRACTORS:
            template_code = FEATURE_EXTRACTORS[template_name]
            self.code_editor.setPlainText(template_code.replace("WORD_EXAMPLE", self.word_example))

    def accept(self):
        self.feature_name = self.feature_name_edit.text()
        self.feature_code = self.code_editor.toPlainText()
        self.weight = float(self.weight_edit.text())
        super().accept()

    def reject(self):
        super().reject()


class ClusteringTab(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window
        self.cluster_parser = TextClusterParser()
        self.initUI()


    def save_state_to_project(self):
        """Save the current state to the project."""
        self.main_window.current_project.feature_extractors = [
            {
                "name": self.feature_table.item(row, 0).text(),
                "weight": float(self.feature_table.item(row, 1).text()),
                "code": self.feature_table.item(row, 2).text(),
            }
            for row in range(self.feature_table.rowCount())
        ]

        # Save the clustering model (except feature extractors) using pickle
        self.main_window.current_project.clustering_model = {
            "feature_union": self.cluster_parser.feature_union,
            "vectorizer": self.cluster_parser.vectorizer,
            "reducer": self.cluster_parser.reducer,
            "clusterer": self.cluster_parser.clusterer,
            "n_clusters": self.cluster_parser.n_clusters,
            "pca_variance": self.cluster_parser.pca_variance,
            "random_state": self.cluster_parser.random_state,
            "fitted": self.cluster_parser.fitted,
            "labels": self.cluster_parser.labels,
            "tagged_lines": self.cluster_parser.tagged_lines,
            "silhouette_avg": self.cluster_parser.silhouette_avg
        }

    def load_content_from_project(self):
        """Load the content from the current project."""
        self.feature_table.setRowCount(0)
        for extractor in self.main_window.current_project.feature_extractors:
            row_position = self.feature_table.rowCount()
            self.feature_table.insertRow(row_position)
            self.feature_table.setItem(row_position, 0, QTableWidgetItem(extractor["name"]))
            self.feature_table.setItem(row_position, 1, QTableWidgetItem(str(extractor["weight"])))
            self.feature_table.setItem(row_position, 2, QTableWidgetItem(extractor["code"]))

            # Recreate the feature extractor
            transformer = self.create_transformer(extractor["code"])
            self.cluster_parser.add_feature_extractor(extractor["name"], transformer, extractor["weight"])

        # Load the clustering model using pickle
        if self.main_window.current_project.clustering_model:
            model_data = self.main_window.current_project.clustering_model
            self.cluster_parser.vectorizer = model_data["vectorizer"]
            self.cluster_parser.reducer = model_data["reducer"]
            self.cluster_parser.clusterer = model_data["clusterer"]
            self.cluster_parser.n_clusters = model_data["n_clusters"]
            self.cluster_parser.pca_variance = model_data["pca_variance"]
            self.cluster_parser.random_state = model_data["random_state"]
            self.cluster_parser.fitted = model_data["fitted"]
            self.cluster_parser.labels = model_data["labels"]
            self.cluster_parser.tagged_lines = model_data["tagged_lines"]
            self.cluster_parser.silhouette_avg = model_data["silhouette_avg"]

            self.n_clusters_edit.setText(str(model_data["n_clusters"]))

    def create_transformer(self, feature_code):
        """Dynamically create a transformer from the provided code."""
        local_vars = {}
        exec(feature_code, globals(), local_vars)


        transformer_class_name = list(local_vars.keys())[0]
        current_module = sys.modules[__name__]
        setattr(current_module, transformer_class_name, local_vars[transformer_class_name])

        return getattr(current_module, transformer_class_name)()

    def display_clusters(self, tagged_lines, cluster_filter_text):
        self.cluster_table.setRowCount(0)  # Clear existing data
        clusters = tagged_lines['Cluster'].unique()

        if cluster_filter_text:
            cluster_filter = list(map(int, cluster_filter_text.split(',')))
            tagged_lines = tagged_lines[tagged_lines['Cluster'].isin(cluster_filter)]

        dc = {}
        for cluster_label in clusters:
            row_position = self.cluster_table.rowCount()
            self.cluster_table.insertRow(row_position)

            # Cluster label
            self.cluster_table.setItem(row_position, 0, QTableWidgetItem(str(cluster_label)))

            # Color associated with the cluster
            color = QColor.fromHsv((cluster_label * 40) % 360, 255, 255, 150).name()
            color_item = QTableWidgetItem()
            color_item.setBackground(QColor(color))
            self.cluster_table.setItem(row_position, 1, color_item)
            dc[str(cluster_label)] = color

        # Display colored text in tagged_text_area
        self.tagged_text_area.clear()
        for _, row in tagged_lines.iterrows():
            colored_text = f'<p style="background-color:{dc[str(row["Cluster"])]}">{row["Line"]}</p>'
            self.tagged_text_area.append(colored_text)

    def add_pos_feature_extractor(self):
        selected_text = self.preprocessed_text_area.textCursor().selectedText()
        if selected_text:
            # Automatically create a feature extractor with the selected text
            feature_code_template = """
class WordExistenceFeatureExtractor(BaseEstimator, TransformerMixin):
    def __init__(self):
        self.words = ["WORD_EXAMPLE"]

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return np.array([[1 if word in text else 0 for word in self.words] for text in X])
"""
            feature_code = feature_code_template.replace("WORD_EXAMPLE", selected_text)
            dialog = FeatureExtractorDialog(self, feature_name=f"Word Existence ({selected_text})",
                                            feature_code=feature_code)
            if dialog.exec_() == QDialog.Accepted:
                row_position = self.feature_table.rowCount()
                self.feature_table.insertRow(row_position)
                self.feature_table.setItem(row_position, 0, QTableWidgetItem(dialog.feature_name))
                self.feature_table.setItem(row_position, 1, QTableWidgetItem(str(dialog.weight)))
                self.feature_table.setItem(row_position, 2, QTableWidgetItem(dialog.feature_code))

                transformer = self.create_transformer(dialog.feature_code)
                self.cluster_parser.add_feature_extractor(dialog.feature_name, transformer, dialog.weight)
                self.main_window.is_project_modified = True
        else:
            QMessageBox.warning(self, "No Text Selected", "Please select some text in the Preprocessed Text area.")

    def add_feature_extractor(self):
        dialog = FeatureExtractorDialog(self)
        if dialog.exec_() == QDialog.Accepted:
            row_position = self.feature_table.rowCount()
            self.feature_table.insertRow(row_position)
            self.feature_table.setItem(row_position, 0, QTableWidgetItem(dialog.feature_name))
            self.feature_table.setItem(row_position, 1, QTableWidgetItem(str(dialog.weight)))
            self.feature_table.setItem(row_position, 2, QTableWidgetItem(dialog.feature_code))

            transformer = self.create_transformer(dialog.feature_code)
            self.cluster_parser.add_feature_extractor(dialog.feature_name, transformer, dialog.weight)
            self.main_window.is_project_modified = True

    def edit_feature_extractor(self):
        current_row = self.feature_table.currentRow()
        if current_row >= 0:
            feature_name_item = self.feature_table.item(current_row, 0)
            weight_item = self.feature_table.item(current_row, 1)
            code_item = self.feature_table.item(current_row, 2)

            dialog = FeatureExtractorDialog(
                self, feature_name=feature_name_item.text(),
                feature_code=code_item.text(), weight=float(weight_item.text())
            )
            if dialog.exec_() == QDialog.Accepted:
                self.feature_table.setItem(current_row, 0, QTableWidgetItem(dialog.feature_name))
                self.feature_table.setItem(current_row, 1, QTableWidgetItem(str(dialog.weight)))
                self.feature_table.setItem(current_row, 2, QTableWidgetItem(dialog.feature_code))

                transformer = self.create_transformer(dialog.feature_code)
                self.cluster_parser.additional_features[current_row] = (
                    dialog.feature_name, WeightedFeatureExtractor(transformer, dialog.weight)
                )
                self.main_window.is_project_modified = True

    def delete_feature_extractor(self):
        current_row = self.feature_table.currentRow()
        if current_row >= 0:
            self.feature_table.removeRow(current_row)
            del self.cluster_parser.additional_features[current_row]
            self.main_window.is_project_modified = True

    def run_clustering(self):
        self.cluster_parser.n_clusters = int(self.n_clusters_edit.text())
        self.cluster_parser.initialize()
        preprocessed_text = self.get_preprocessed_text()
        text_lines = preprocessed_text.splitlines()

        # Display the preprocessed text
        self.preprocessed_text_area.setPlainText(preprocessed_text)

        # Fit and get the tagged lines
        tagged_lines = self.cluster_parser.fit(text_lines)

        # Filter clusters based on user input
        cluster_filter_text = self.cluster_filter_edit.text()

        # Display clusters
        self.display_clusters(tagged_lines, cluster_filter_text)

    def initUI(self):
        main_layout = QVBoxLayout()

        # Create a horizontal layout for the two text areas
        text_area_layout = QHBoxLayout()

        # Preprocessed text preview
        self.preprocessed_text_area = QTextEdit(self)
        self.preprocessed_text_area.setReadOnly(True)
        text_area_layout.addWidget(self.preprocessed_text_area)

        # Tagged text preview
        self.tagged_text_area = QTextBrowser(self)
        text_area_layout.addWidget(self.tagged_text_area)

        # Add the horizontal layout to the main layout
        main_layout.addLayout(text_area_layout)

        tables_layout = QHBoxLayout()

        # QTableWidget for storing feature extractors
        self.feature_table = QTableWidget(0, 3, self)
        self.feature_table.setHorizontalHeaderLabels(["Feature Name", "Weight", "Code"])

        header = self.feature_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Stretch)
        tables_layout.addWidget(self.feature_table)

        # QTableWidget for displaying clusters and colors
        self.cluster_table = QTableWidget(0, 2, self)
        self.cluster_table.setHorizontalHeaderLabels(["Cluster Label", "Color"])

        header = self.cluster_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Stretch)
        tables_layout.addWidget(self.cluster_table)

        main_layout.addLayout(tables_layout)

        # Feature Extractor Toolbox
        toolbox_layout = QHBoxLayout()

        self.show_raw_button = QPushButton("Show Baseline", self)
        self.show_raw_button.clicked.connect(self.show_baseline)
        toolbox_layout.addWidget(self.show_raw_button)

        self.add_button = QPushButton("Add Feature Extractor", self)
        self.add_button.clicked.connect(self.add_feature_extractor)
        toolbox_layout.addWidget(self.add_button)

        self.edit_button = QPushButton("Edit Feature Extractor", self)
        self.edit_button.clicked.connect(self.edit_feature_extractor)
        toolbox_layout.addWidget(self.edit_button)

        self.delete_button = QPushButton("Delete Feature Extractor", self)
        self.delete_button.clicked.connect(self.delete_feature_extractor)
        toolbox_layout.addWidget(self.delete_button)

        self.pos_button = QPushButton("POS", self)
        self.pos_button.clicked.connect(self.add_pos_feature_extractor)
        toolbox_layout.addWidget(self.pos_button)

        self.test_button = QPushButton("Run Clustering", self)
        self.test_button.clicked.connect(self.run_clustering)
        toolbox_layout.addWidget(self.test_button)

        self.n_clusters_label = QLabel("Clusters:")
        toolbox_layout.addWidget(self.n_clusters_label)

        self.n_clusters_edit = QLineEdit(self)
        self.n_clusters_edit.setText(str(self.cluster_parser.n_clusters))
        toolbox_layout.addWidget(self.n_clusters_edit)

        self.cluster_filter_label = QLabel("Filter Clusters (comma-separated):")
        toolbox_layout.addWidget(self.cluster_filter_label)

        self.cluster_filter_edit = QLineEdit(self)
        toolbox_layout.addWidget(self.cluster_filter_edit)

        main_layout.addLayout(toolbox_layout)
        self.setLayout(main_layout)

    def display_clusters2(self, tagged_lines):
        colored_text = ""
        for _, row in tagged_lines.iterrows():
            color = QColor.fromHsv((row['Cluster'] * 40) % 360, 255, 255, 150).name()
            colored_text += f'<p style="background-color:{color}">{row["Line"]}</p>'
        self.tagged_text_area.setHtml(colored_text)

    def show_baseline(self):
        preprocessed_text = self.get_preprocessed_text()
        self.preprocessed_text_area.setPlainText(preprocessed_text)

    def get_preprocessed_text(self):
        # Execute the preprocessing steps defined in the PreprocessingTab
        preprocessed_text = self.main_window.preprocessing_tab.execute_operations()
        return "\n".join(preprocessed_text)
